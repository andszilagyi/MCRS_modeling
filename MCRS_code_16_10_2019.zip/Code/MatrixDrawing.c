#include  "MRM_RNA_complementer.h"

void MatrixDrawing(double **matrix, int m, int time) 
{
/** **********************************************
	matrix:		matrix which will be drawed
	m:				size of matrix
	time:			generation time
********************************************** **/ 
	int space=1*3,OS=1;
	unsigned char bmp[m*((m*3*3)+(space*2))]; /*sorok száma: m, oszlopok szama:  m + 10 + m + 10 + m */
	register int i,j;
	/* To Pheno-geno */
	/*int color[9][3]={{255,255,255},{4,253,64},{2,81,20},{55,4,255},{22,3,100},{253,6,39},{85,6,17},{250,242,3},{250,180,4}};*/ 
	/* To Origianl*/
	/*int color[9][3]={{255,255,255},{0,255,0},{0,0,0},{0,0,255},{0,0,0},{255,0,0},{0,0,0},{255,255,0},{0,0,0}};*/
	/*double hatar[7]={0.0,0.2,0.4,0.6,0.8,1.0,1.1};
	int blue[7][3]={{255,255,255},{153,204,255},{135,206,250},{72,118,255},{58,95,205},{39,64,139},{0,34,102}};
	int red[7][3]={{255,255,255},{255,182,193},{238,162,173},{255,48,48},{255,0,0},{205,0,0},{139,0,0}};
	int green[7][3]={{255,255,255},{202,255,112},{162,205,90},{0,238,0},{50,205,50},{0,139,0},{0,100,0}};*/
	/*int mm,num,ii;*/ 
	int column,row;
	/*char *string;*/
	
	column=((m*3*3)+(space*2));
	row=m;
	
	memset(bmp, 255, sizeof(bmp));
	/*printf("%d %d\n",row*column,sizeof(bmp));*/
	for(i=0;i<m;i++)
  {
		for(j=0;j<m;j++)
		{
			/*printf("[%d,%d (%d)]: %2.8f %2.8f %2.8f ",i,j,(i*m)+j, matrix[(i*m)+j][1],matrix[(i*m)+j][2],matrix[(i*m)+j][3]);*/
			if((matrix[(i*m)+j][1]>0) && (matrix[(i*m)+j][2]==0) && (matrix[(i*m)+j][3]==0))
			{
				/** Enzymatic activity 1 -- blue **/
				/*printf("E2: %d + 0..2\t",(i*column)+(j*3));*/
				bmp[(i*column)+(j*3)+ 0] = 0;
				bmp[(i*column)+(j*3)+ 1] = 0;
				bmp[(i*column)+(j*3)+ 2] = (int)255-(pow((matrix[(i*m)+j][1]/1.1),2.0)*(255-120));
				/*printf("rgb: %d %d %d\n", bmp[(i*column)+(j*3)+ 0],bmp[(i*column)+(j*3)+ 1],bmp[(i*column)+(j*3)+ 2]);*/
			}
			else if((matrix[(i*m)+j][1]==0) && (matrix[(i*m)+j][2]>0) && (matrix[(i*m)+j][3]==0))
			{
				/** Enzymatic activity 2 -- red **/
				/*printf("E2: %d + 0..2\t",(i*column)+((m*3)+space)+(j*3));*/
				bmp[(i*column)+((m*3)+space)+(j*3)+0]=(int)255-(pow((matrix[(i*m)+j][2]/1.1),2.0)*(255-120));
				bmp[(i*column)+((m*3)+space)+(j*3)+1] = 0;
				bmp[(i*column)+((m*3)+space)+(j*3)+2] = 0;
				/*printf("rgb: %d %d %d\n", bmp[(i*column) + ((m*3)+space) + (j*3) + 0],bmp[(i*column) + ((m*3)+space) + (j*3) + 1],bmp[(i*column) + ((m*3)+space) + (j*3) + 2]);*/
			}
			else if((matrix[(i*m)+j][1]==0) && (matrix[(i*m)+j][2]==0) && (matrix[(i*m)+j][3]>0))
			{
				/** Enzymatic activity 3 -- green **/
				/*printf("E3: %d + 0..2\t",(i*column)+((m*3*2)+(space*2))+(j*3));*/
				bmp[(i*column)+((m*3*2)+(space*2))+(j*3)+0]=0;
				bmp[(i*column)+((m*3*2)+(space*2))+(j*3)+1]=(int)255-(pow((matrix[(i*m)+j][3]/1.1),2.0)*(255-120));
				bmp[(i*column)+((m*3*2)+(space*2))+(j*3)+2]=0;
				/*printf("rgb: %d %d %d\n", bmp[(i*column) + ((m*3*2)+(space*2))+(j*3)+ 0],bmp[(i*column)+ ((m*3*2)+(space*2))+(j*3)+1],bmp[(i*column) + ((m*3*2)+(space*2))+(j*3)+2]);*/
			}
			else /*printf("\n")*/;
			
		}
		
		/** SPACER REGIONS **/
	bmp[(i*column)+((m*3))+0] = 230;
	bmp[(i*column)+((m*3))+1] = 230;
	bmp[(i*column)+((m*3))+2] = 230;
		
	bmp[(i*column)+((m*3*2)+space)+0] = 230;
	bmp[(i*column)+((m*3*2)+space)+1] = 230;
	bmp[(i*column)+((m*3*2)+space)+2] = 230;
		
	}
	
	
			
	/*printing in *pnm file*/
	MatrixRajz=fopen("temp.pnm", "wt");
	fprintf(MatrixRajz, "P3\n# rem\n%d %d\n255\n", (int)column/3, row);
  /*fwrite(bmp, 1, sizeof(bmp), MatrixRajz);*/
	/*for(i=0;i<sizeof(bmp);i++) 
	{
		fprintf(MatrixRajz,"%d ",bmp[i]);
		if(((i % column == 0) && (i>0)))
			fprintf(MatrixRajz, "\n");
	}*/
	for(i=0;i<row;i++)
	{
		for(j=0;j<column;j++) 
			fprintf(MatrixRajz,"%d ",bmp[(i*column)+j]);
		fprintf(MatrixRajz,"\n");
	}
	/*fprintf(MatrixRajz,"\n\n");*/
	fclose(MatrixRajz);
	
	/* convert: (picture) pnm -> png -> mpeg (video)*/
	
	/*string=(char*) calloc(1000,sizeof(char));
  if(string==NULL) exit(1);*/
	/* to pictures */
	/*strcpy(string,"cp temp.png temp_");
	sprintf(string,"cp temp.png temp_%d",time);
	strcat(string,".png");
	printf("%s\n",string);
	system (string);*/
	
	/* to movie */
	OS=OS;
	OS=system("rm -rf temp.png");
	OS=system("convert temp.pnm temp.png");	
	OS=system("rm -rf temp.mpeg");
	OS=system("ffmpeg -i temp.png -f mpeg -b 18000k temp.mpeg > /dev/null 2>&1");
	OS=system("cat temp.mpeg >> final.mpeg");
	/*free(string);*/
}

