#include  "MRM_RNA_complementer.h"

/** it works only n=3, where n is the number of enzymatic activities **/
double printing(int time,int mm,double **Activity,int EnzymeTypes,double *res, int PrintingProperties, char **SeqMatrix, double BoltzmannConst, double cc,int *L, double aa, double bb)
{
/** *

# M -- mean
# SD -- standard deviation
# 1,2,3 -- type of enzyme
# k -- kinetic replication parameters (replication rate)
# L -- length of RNA molecules

# Content OF Res (n-2 in vector): 
# 				0				1					2		3	 4  5   6    7   8  9		10	11	12	13	 14	15	16
# (1)			2				3					4		5	 6 	7		8		 9	 10	11	12  13 	14  15   16 17  18     
# (Time) Empty Functionless Mk SDk ML SDL E100 M1 SD1 Mk1 SDk1 ML SDL E020 M2 SD2 Mk2 

#	17	 18	19	20	 21	22	23	24	 25	26	27	 28	29	30	31	32	33		34	35	36
# 19   20	21	22   23 24  25	26	 27	28	29	 30	31	32	33	34	35		36	37	38
# SDk2 ML	SDL	E003 M3 SD3 Mk3 SDk3 ML SDL E120 M1 SD1 M2 SD2 Mk12 SDk12 ML SDL E103

#	37	38 39	40	41		42		43	44	45		46	47	48	49	50		51	 52	53	54		 55	
# 39	40 41 42	43		44		45	46	47		48	49	50	51	52		53	 54	55	56		 57
# M1 SD1 M3 SD3 Mk13 SDk13	ML SDL  E023 	M2 SD2 	M3 SD3	Mk23 SDk23 ML SDL E1E2E3 M1

#	56	57	58	59 60	 61		 62			63	64	65
# 58	59	60  61 62  63    64  		65  66	67
# SD1 M2 SD2 M3 SD3 Mk123 SDk123	ML	SDL EMMM	

BoltzmannConst=0.3
cc=10
RepRate (k)=(1.0+(1.0/(1.0+exp(BoltzmannConst*enzyme[RepNeigh[(poz*NumOfRepNeigh)+i]][0]))))*cc

**/
	int i,ii,j,type=0,type2=0,NoEA=0,k=0,ll=0;
	int NumOfRepType=factorial(EnzymeTypes)+3; /* if n=3: Empty + E1 + E2 + E3 + E1E2 + E1E3 + E2E3 + E1E2E3 + Functionless */
	double **EnzymeActivities,kk=0.0,SD=0.0;
	/*char *code[28][3]={{"0","0","0"},{"E000","1","2"},{"E100","6","3"},{"E020","13","3"},{"E003","20","3"},{"E120","27","4"},{"E103","36","4"},{"E023","45","4"},{"E123","54","5"},{"EMMM","65","2"},{"EM00","65","2"},{"E0M0","65","2"},{"E00M","65","2"},{"EMM0","65","2"},{"EM0M","65","2"},{"E0MM","65","2"},{"E10M","65","2"},{"E1M0","65","2"},{"E1MM","65","2"},{"E02M","65","2"},{"EM20","65","2"},{"EM2M","65","2"},{"EM03","65","2"},{"E0M3","65","2"},{"EMM3","65","2"},{"E12M","65","2"},{"E1M3","65","2"},{"EM23","65","2"}};
	char *code2[28][2]={{"0","0"},{"E000","1"},{"E100","2"},{"E020","3"},{"E003","4"},{"E120","5"},{"E103","6"},{"E023","7"},{"E123","8"},{"EMMM","9"},{"EM00","9"},{"E0M0","9"},{"E00M","9"},{"EMM0","9"},{"EM0M","9"},{"E0MM","9"},{"E10M","9"},{"E1M0","9"},{"E1MM","9"},{"E02M","9"},{"EM20","9"},{"EM2M","9"},{"E0M3","9"},{"EM03","9"},{"EMM3","9"},{"E12M","9"},{"E1M3","9"},{"EM23","9"}};*/
	
	char *code[28][3]={{"0","0","0"},{"E000","1","2"},{"E100","6","3"},{"E020","13","3"},{"E003","20","3"},{"E120","27","4"},{"E103","36","4"},{"E023","45","4"},{"E123","54","5"},{"EMMM","54","5"},{"EM00","6","3"},{"E0M0","13","3"},{"E00M","20","3"},{"EMM0","27","4"},{"EM0M","36","4"},{"E0MM","45","4"},{"E10M","36","4"},{"E1M0","27","4"},{"E1MM","54","5"},{"E02M","45","4"},{"EM20","27","4"},{"EM2M","54","5"},{"EM03","36","4"},{"E0M3","45","4"},{"EMM3","54","5"},{"E12M","54","5"},{"E1M3","54","5"},{"EM23","54","5"}};
	char *code2[28][2]={{"0","0"},{"E000","1"},{"E100","2"},{"E020","3"},{"E003","4"},{"E120","5"},{"E103","6"},{"E023","7"},{"E123","8"},{"EMMM","8"},{"EM00","2"},{"E0M0","3"},{"E00M","4"},{"EMM0","5"},{"EM0M","6"},{"E0MM","7"},{"E10M","6"},{"E1M0","5"},{"E1MM","8"},{"E02M","7"},{"EM20","5"},{"EM2M","8"},{"E0M3","7"},{"EM03","6"},{"EMM3","8"},{"E12M","8"},{"E1M3","8"},{"EM23","8"}};
	
	
	int Energy[10][26];
	char *s=NULL,*sn=NULL;
	
	/*printf("IN PRINTING (%d)\n",time);*/
	/*printf("NumOfRepType= %d\n",NumOfRepType);*/

	
	for(i=0;i<10;i++)
	{
		for(j=0;j<26;j++)
			Energy[i][j]=0;
	}


/** **/

	/*for(i=0;i<mm;i++)
	{
		SeqMatrix[i]='\0';
		L[i]=0;
		Activity[i][0]=Activity[i][1]=Activity[i][2]=Activity[i][3]=0.00;		
	}	

	SeqMatrix[0]="AAAG"; L[0]=5;
 	SeqMatrix[1]="AAAG"; L[1]=5;Activity[1][0]=0.50;Activity[1][1]=2.00;
 	SeqMatrix[2]="AAAG";L[2]=5;Activity[2][0]=0.50;Activity[2][2]=2.00;
 	SeqMatrix[3]="AAAG";L[3]=5;Activity[3][0]=0.50;Activity[3][3]=2.00;
 	SeqMatrix[4]="AAAG";L[4]=5;Activity[4][0]=0.50;Activity[4][1]=2.00;Activity[4][2]=2.00;
 	SeqMatrix[5]="AAAG";L[5]=5;Activity[5][0]=0.50;Activity[5][1]=2.00;Activity[5][3]=2.00;
 	SeqMatrix[6]="AAAG";L[6]=5;Activity[6][0]=0.50;Activity[6][2]=2.00;Activity[6][3]=2.00;
 	SeqMatrix[7]="AAAG";L[7]=5;Activity[7][0]=0.50;Activity[7][1]=2.00;Activity[7][2]=2.00;Activity[7][3]=2.00;

 	SeqMatrix[8]="AAAG"; L[8]=6;
 	SeqMatrix[9]="AAAG";L[9]=6;Activity[9][0]=0.60;Activity[9][1]=1.00;
 	SeqMatrix[10]="AAAG";L[10]=6;Activity[10][0]=0.60;Activity[10][2]=1.00;
 	SeqMatrix[11]="AAAG";L[11]=6;Activity[11][0]=0.60;Activity[11][3]=1.00; 	
	SeqMatrix[12]="AAAG";L[12]=6;Activity[12][0]=0.60;Activity[12][1]=1.00;Activity[12][2]=1.00;
 	SeqMatrix[13]="AAAG";L[13]=6;Activity[13][0]=0.60;Activity[13][1]=1.00;Activity[13][3]=1.00;
 	SeqMatrix[14]="AAAG";L[14]=6;Activity[14][0]=0.60;Activity[14][2]=1.00;Activity[14][3]=1.00; 	
	SeqMatrix[15]="AAAG";L[15]=6;Activity[15][0]=0.60;Activity[15][1]=1.00;Activity[15][2]=1.00;Activity[15][3]=1.00;
	
	SeqMatrix[16]="AAAG";L[16]=6;Activity[16][0]=0.60;Activity[16][1]=0.00;Activity[16][2]=0.00;Activity[16][3]=0.01;
	SeqMatrix[17]="AAAG";L[17]=6;Activity[17][0]=0.60;Activity[17][1]=0.00;Activity[17][2]=0.01;Activity[17][3]=0.00;
	SeqMatrix[18]="AAAG";L[18]=6;Activity[18][0]=0.60;Activity[18][1]=0.00;Activity[18][2]=0.01;Activity[18][3]=0.01;
	SeqMatrix[19]="AAAG";L[19]=6;Activity[19][0]=0.60;Activity[19][1]=0.01;Activity[19][2]=0.01;Activity[19][3]=0.00;
	SeqMatrix[20]="AAAG";L[20]=6;Activity[20][0]=0.60;Activity[20][1]=0.01;Activity[20][2]=0.00;Activity[20][3]=0.01;
	SeqMatrix[21]="AAAG";L[21]=6;Activity[21][0]=0.60;Activity[21][1]=0.00;Activity[21][2]=0.01;Activity[21][3]=0.01;
	SeqMatrix[22]="AAAG";L[22]=6;Activity[22][0]=0.60;Activity[22][1]=0.01;Activity[22][2]=0.00;Activity[22][3]=0.01;
	SeqMatrix[23]="AAAG";L[23]=6;Activity[23][0]=0.60;Activity[23][1]=0.01;Activity[23][2]=0.01;Activity[23][3]=0.01;
	SeqMatrix[24]="AAAG";L[24]=6;Activity[24][0]=0.60;Activity[24][1]=0.01;Activity[24][2]=0.00;Activity[24][3]=0.00;*/
/** **/

	s=(char*) calloc(10,sizeof(char));
  if (s==NULL) exit (1);
	sn=(char*) calloc(10,sizeof(char));
  if (sn==NULL) exit (1);
	/*num=(double*)calloc(NumOfRepType,sizeof(double));
	if(num==NULL) {printf("Memoria foglalasi gond2\n") ;exit(1);};*/

	
	EnzymeActivities=(double**) calloc(28*EnzymeTypes,sizeof(double*));
	if(EnzymeActivities==NULL) {printf("Memoria foglalasi gond2\n") ;exit(1);};
	for(i=0;i<28;i++)
		EnzymeActivities[i]=(double*) calloc(EnzymeTypes,sizeof(double));
	
	
	/*printf("Tul a memoria fogalalason\n");
	printf("mm= %d %f\n",mm,Activity[(mm-1)][0]);*/
	for(i=0;i<PrintingProperties;i++)
	{
		res[i]=0.00;
		/*printf("res[%d]= %f\n",i,res[i]);*/
	}
	
	
/* NUMBER OF REPCLICATOR TYPES */	
	for(i=0;i<mm;i++)
	{
/*f(time==3192)		
	printf("i= %d, %s::%d, (%f, %f, %f, %f)\t",i,SeqMatrix[i],L[i],Activity[i][0],Activity[i][1],Activity[i][2],Activity[i][3]);*/
		if(L[i]>0)
		{
			strcpy(s,"E");
			for(j=1;j<=EnzymeTypes;j++)
			{
				if(Activity[i][j]>0.01) /*Real enzyme*/
				{
					sprintf(sn,"%d",j);
					strcat(s,sn);
				}
				else if((Activity[i][j]>0.0)&&(Activity[i][j]<=0.01))
					strcat(s,"M");
				else strcat(s,"0");
			}
			
			if(strcmp(s,code[8][0])==0)
				fprintf(E1E2E3,"%s %d %f %f %f %f\n",SeqMatrix[i],L[i],Activity[i][0],Activity[i][1],Activity[i][2],Activity[i][3]);		
/*if(time==3192)			
	printf("\t\t%d) s= %s\t",i,s);*/

			for(j=0;j<28;j++)
			{
				if(strcmp(s,code[j][0])==0)
				{
					type=atoi(code[j][1]);
					NoEA=j;
					k=type+1+(2*(atoi(code[j][2])-2));
					ll=k+2;
					break;
				}
			}
/*if(time==3192)
	printf("Code=(%s,%s,%s), NUM: type= %d NoEA= %d, k= %d,ll= %d\t",code[j][0],code[j][1],code[j][2],type, NoEA,k,ll);*/
		
			
			res[type]+=1.0; /* number of enzymatic Replicator type */
/*printf("res[%d]= %f\n",type,res[type]);*/
			
	
			if(type<65)
			{
				res[k]+=(1.00/(aa+(bb*L[i])))*(1.0+(1.0/(1.0+exp(BoltzmannConst*Activity[i][0]))))*cc;
/*printf("res[%d]= %f\n",k,res[k]);*/
				for(j=1;j<=EnzymeTypes;j++)
				{
					EnzymeActivities[NoEA][j-1]+=Activity[i][j]; /*sum of Enzymatic activities of the replicator type*/
				}
/*printf("EA[%d][%d]= %f, EA[%d][%d]= %f, EA[%d][%d]= %f\n",NoEA,0,EnzymeActivities[NoEA][0],NoEA,1,EnzymeActivities[NoEA][1],NoEA,2,EnzymeActivities[NoEA][2]);	*/		
				res[ll]+=L[i];
/*printf("res[%d]= %f\n",ll,res[ll]);*/
				for(ii=0;ii<28;ii++)
				{
					if(strcmp(s,code2[ii][0])==0)
					{
/*if(time==3192)
	printf("Code2=(%s,%s)\n",code2[ii][0],code2[ii][1]);*/
						type2=atoi(code2[ii][1]);
						for(j=0;j<26;j++)
						{
							if((Activity[i][0]>=j)&&(Activity[i][0]<(j+1)))
							{
								Energy[type2][j]+=1;
								break;
							}
						}
						break;
					}
					else;
				}
/*for(ii=0;ii<10;ii++)
{*/
	/*for(j=0;j<25;j++)
		printf("ENERGY[%d][%d]= %d\t",ii,j,Energy[ii][j]);
	printf("\n");*/
/*}*/
			}
			
		}
		else {res[0]+=1.0;/*printf("%d) EMPTY\n",i);*/} /*Empty site*/
	}
/*if(time==3192)
{
	for(i=0;i<PrintingProperties;i++)
		printf("res[%d]= %f\n",i,res[i]);
}

if(time==3192)
{
	for(i=0;i<10;i++)
	{
		printf("%s)\t",code2[i][0]);
		for(j=0;j<26;j++)
			printf("%d ",Energy[i][j]);
		printf("\n");
	}
}*/

	/** ENERGY DISTRIBUTION **/
	fprintf(EnergyE1,"%d ",time);
	for(j=0;j<26;j++)
		fprintf(EnergyE1,"%d ",Energy[2][j]);
	fprintf(EnergyE1,"\n");
	fflush(EnergyE1);

	fprintf(EnergyE2,"%d ",time);
	for(j=0;j<26;j++)
		fprintf(EnergyE2,"%d ",Energy[3][j]);
	fprintf(EnergyE2,"\n");
	fflush(EnergyE2);

	fprintf(EnergyE3,"%d ",time);
	for(j=0;j<26;j++)
		fprintf(EnergyE3,"%d ",Energy[4][j]);
	fprintf(EnergyE3,"\n");
	fflush(EnergyE3);

	fprintf(EnergyE12,"%d ",time);
	for(j=0;j<26;j++)
		fprintf(EnergyE12,"%d ",Energy[5][j]);
	fprintf(EnergyE12,"\n");
	fflush(EnergyE12);
	
	fprintf(EnergyE13,"%d ",time);
	for(j=0;j<26;j++)
		fprintf(EnergyE13,"%d ",Energy[6][j]);
	fprintf(EnergyE13,"\n");
	fflush(EnergyE13);
	
	fprintf(EnergyE23,"%d ",time);
	for(j=0;j<26;j++)
		fprintf(EnergyE23,"%d ",Energy[7][j]);
	fprintf(EnergyE23,"\n");
	fflush(EnergyE23);
	
	fprintf(EnergyE123,"%d ",time);
	for(j=0;j<26;j++)
		fprintf(EnergyE123,"%d ",Energy[8][j]);
	fprintf(EnergyE123,"\n");
	fflush(EnergyE123);

	fprintf(EnergyFunctionless,"%d ",time);
	for(j=0;j<26;j++)
		fprintf(EnergyFunctionless,"%d ",Energy[1][j]);
	fprintf(EnergyFunctionless,"\n");
	fflush(EnergyFunctionless);
	
	for(i=0;i<10;i++)
	{
		for(j=0;j<26;j++)
			Energy[i][j]=0;
	}
/*if(time==3193)
	exit(115);	*/
/** **/
	for(i=0;i<NumOfRepType;i++)
	{
		type=atoi(code[i][1]);
		NoEA=type+1;
		/*printf("type= %d, NoEA= %d\n",type,NoEA);*/
		/*printf("res[%d][%d]= %f (",time,type,res[time][type]);*/
		/*if(type<65)
		{*/
			for(j=0;j<EnzymeTypes;j++)
			{
				if(EnzymeActivities[i][j]>0.01)
				{
					res[NoEA]=EnzymeActivities[i][j];
					/*printf("res[%d][%d]=%f, ",time, NoEA,res[time][NoEA]);*/
					NoEA+=2;
				}
			}
		/*}*/
	}
/*for(i=0;i<PrintingProperties;i++)
	printf("2) res[%d]= %f\n",i,res[i]);*/

	
/* MEAN */
	for(i=1;i<NumOfRepType;i++)
	{
		type=atoi(code[i][1]);		
		NoEA=type+1;
		k=type+1+(2*(atoi(code[i][2])-2));
		ll=k+2;
/*printf("M: type= %d NoEA= %d, k= %d, ll= %d\n",type, NoEA,k,ll);*/
		
		if(res[type]>1)
		{
			for(j=0;j<EnzymeTypes;j++)
			{
				if(EnzymeActivities[i][j]>0.01)
				{
					res[NoEA]/=(res[type]);
					NoEA+=2;
				}
			}
			res[k]/=res[type];
			res[ll]/=res[type];
		}
	}

/*for(i=0;i<PrintingProperties;i++)
	printf("3) res[%d]= %f\n",i,res[i]);*/


/* STANDARD DEVIATION */
	
	for(i=0;i<mm;i++)
	{
		if(L[i]>0)
		{
			strcpy(s,"E");
			for(j=1;j<=EnzymeTypes;j++)
			{
				if(Activity[i][j]>0.01) /*Real enzyme*/
				{
					sprintf(sn,"%d",j);
					strcat(s,sn);
				}
				else if((Activity[i][j]>0.0)&&(Activity[i][j]<=0.01))
					strcat(s,"M");
				else strcat(s,"0");
			}
			
			for(j=0;j<28;j++)
			{
				if(strcmp(s,code[j][0])==0)
				{
					type=atoi(code[j][1]);
					NoEA=type+2;
					k=type+2+(2*(atoi(code[j][2])-2));
					ll=k+2;
					break;
				}
			}
/*printf("SD: type= %d NoEA= %d, k= %d,ll= %d, NoEA-1= %d, k-1= %d, ll-1= %d\n",type, NoEA,k,ll, NoEA-1,k-1,ll-1);
			
printf("%d) %f %f %f\n",i,Activity[i][1],Activity[i][2],Activity[i][3]);*/

			if(type<65)
			{
/*printf("type<65\n");*/
				for(j=1;j<=EnzymeTypes;j++)
				{
					if(Activity[i][j]>0.01)
					{
						/*printf("%d) %f\n",i,pow((Activity[i][j]-res[time][NoEA-1]),2.00));*/
						res[NoEA]+=pow((Activity[i][j]-res[NoEA-1]),2.00);
						/*printf("res[%d][%d]= %f\n",time,NoEA,res[time][NoEA]);*/
						NoEA+=2;
					}
					/*EnzymeActivities[NoEA][j-1]=Activity[i][j];*/ /*sum of Enzymatic activities of the replicator type*/
				}
				kk=(1.0+(1.0/(1.0+exp(BoltzmannConst*Activity[i][0]))))*cc;
				res[k]+=pow((kk-res[k-1]),2.00);
				res[ll]+=pow((L[i]-res[ll-1]),2.00);
			}
		}
		
	}

	for(i=1;i<NumOfRepType;i++)
	{
		type=atoi(code[i][1]);
		NoEA=type+2;
		k=type+2+(2*(atoi(code[i][2])-2));
		ll=k+2;
/*printf("SD2: type= %d NoEA= %d, k= %d,ll= %d, NoEA-1= %d, k-1= %d, ll-1= %d\n",type, NoEA,k,ll, NoEA-1,k-1,ll-1);*/
		if(res[type]>1)
		{
			for(j=0;j<EnzymeTypes;j++)
			{
				if(EnzymeActivities[i][j]>0.01)
				{
					SD=pow((res[NoEA]/(res[type]-1)),0.5);
					res[NoEA]=SD;
					NoEA+=2;
				}
			}
			SD=pow((res[k]/(res[type]-1)),0.5);
			res[k]=SD;
			SD=pow((res[ll]/(res[type]-1)),0.5);
			res[ll]=SD;
		}
		
	}
/*for(i=0;i<PrintingProperties;i++)
	printf("4) res[%d]= %f ",i,res[i]);
printf("\n\n");*/
/*exit(223);*/
	
	
	
	free(s);
	free(sn);
	for(i=0;i<28;i++)
		free(EnzymeActivities[i]);
	free(EnzymeActivities);
	
	/*printf("left\n");*/
	return res[0]; /*Empty*/
}
