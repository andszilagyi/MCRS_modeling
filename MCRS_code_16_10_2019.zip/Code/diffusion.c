/*******************************************************************************
                         DIFFUSION OF REPLICATORS (Toffoli-Margolus)
*******************************************************************************/
#include  "MRM_RNA_complementer.h"

void diffusion(int m,int *dneigh, char **grid, double **properties,int NumOfProperties , int *length)
{/*difusion*/
/*******************************************************************************
m:      the whole size of matrix
dneigh: neighbourhoods of given point
grid:   matrix
********************************************************************************/

  int i,j, kkk;
	char *k=NULL;
	double kk;
	
	k=(char*)calloc(1000,sizeof(char));
	if(k==NULL) exit(1);

  /*printf("###########\n DIFFUSION \n###########\n");*/

  i=randl((m*m));
/*printf("i= %d\n",i);*/
  if(randl(2)==0)
  {
/*printf("jobbra teker\n");*/

		strcpy(k,grid[dneigh[(i*4)+0]]);
		strcpy(grid[dneigh[(i*4)+0]],grid[dneigh[(i*4)+1]]);
		strcpy(grid[dneigh[(i*4)+1]],grid[dneigh[(i*4)+3]]);
		strcpy(grid[dneigh[(i*4)+3]],grid[dneigh[(i*4)+2]]);
		strcpy(grid[dneigh[(i*4)+2]],k);
		
		for(j=0;j<NumOfProperties;j++)
		{
			kk=properties[dneigh[(i*4)+0]][j];
			properties[dneigh[(i*4)+0]][j]=properties[dneigh[(i*4)+1]][j];
			properties[dneigh[(i*4)+1]][j]=properties[dneigh[(i*4)+3]][j];
			properties[dneigh[(i*4)+3]][j]=properties[dneigh[(i*4)+2]][j];
			properties[dneigh[(i*4)+2]][j]=kk;
		}
		
		kkk=length[dneigh[(i*4)+0]];
		length[dneigh[(i*4)+0]]=length[dneigh[(i*4)+1]];
		length[dneigh[(i*4)+1]]=length[dneigh[(i*4)+3]];
		length[dneigh[(i*4)+3]]=length[dneigh[(i*4)+2]];
		length[dneigh[(i*4)+2]]=kkk;

  }
  else
  {
/*printf("balra teker\n");*/
		strcpy(k,grid[dneigh[(i*4)+0]]);
		strcpy(grid[dneigh[(i*4)+0]],grid[dneigh[(i*4)+2]]);
		strcpy(grid[dneigh[(i*4)+2]],grid[dneigh[(i*4)+3]]);
		strcpy(grid[dneigh[(i*4)+3]],grid[dneigh[(i*4)+1]]);
		strcpy(grid[dneigh[(i*4)+1]],k);
					
		for(j=0;j<NumOfProperties;j++)
		{
			kk=properties[dneigh[(i*4)+0]][j];
			properties[dneigh[(i*4)+0]][j]=properties[dneigh[(i*4)+2]][j];
			properties[dneigh[(i*4)+2]][j]=properties[dneigh[(i*4)+3]][j];
			properties[dneigh[(i*4)+3]][j]=properties[dneigh[(i*4)+1]][j];
			properties[dneigh[(i*4)+1]][j]=kk;
		}
		
		kkk=length[dneigh[(i*4)+0]];
		length[dneigh[(i*4)+0]]=length[dneigh[(i*4)+2]];
		length[dneigh[(i*4)+2]]=length[dneigh[(i*4)+3]];
		length[dneigh[(i*4)+3]]=length[dneigh[(i*4)+1]];
		length[dneigh[(i*4)+1]]=kkk;
		
  }
  
  free(k);

}/*difusion*/

