#include  "MRM_RNA_complementer.h"

/**
Model:
Metabolically Coupled Replicator System on surface + RNA sequences
- each replicator is RNA sequence
- RNA sequence is folded by Vienna RNA package
-
- simple secondary structure as enzymatically acive site: 1) inside-loop 2) small loop, 3) grater loop
- Enzymactivities is discrete: 1) size of loop is the same az enzyme type -- basic activity (0.01), 2) size of loop is smaller than enzyme type but in the catalytic pozition a given base can be found -- activity: 0.10, 3) size and cataalityc base is correct -- activity: 1.00
-	Helper base at coles the active base may assist in the catalitic reaction: enzymatic activity * 1.1
- Metabolic efficiency depends on: 
	1) replication rate which depends on the stability of replicator: instable structure -- more probability for replication, stable structure -- less probability for replication. Probability is calculated by Boltzmann distribution (P=1/(1+EXP(c*E),  2) More enzymatic activitis may be in one sequence, but it is punished 1/x^1.1 wher x is the number of activity of the sequence, 
	3) a weker structure may lost his enzymatic activity with more probability (P=1/(1+EXP(-c*E)), 
	4) the time of replication depends on the length of sequence (1/(a+b*L)) 
- Sequences may suffer from Insertion, Deletion and Substitution
- Diffusion on surface



**/
void test_printing(int,int,int,char**,int*, double**);
void final_printing(int,int,int,char**,int*, double**,int,long long int,char*,int *, int, double, int, double, double);
FILE *fp, *final,  *RandNumberBeallitashoz,*fpp;
int main(int argc, char *argv[])
{
	/* MODEL PARAMETERS */
  int m=atoi(argv[1])/*100*/; /*size of matrix - m*/
  int gt=atoi(argv[2])/*1000*/;  /*number of generation time - gt*/
  int wf=atoi(argv[3])/*2*/; /*frequency of writing - wf*/
  int D=atoi(argv[4])/*1*/;  /*number of difusion steps - D*/
  int h=atoi(argv[5])/*1*/; /*size of metabolic neighbourhoods - h*/
  int r=/*atoi(argv[6])*/0; /*size of replication neighbourhoods - r*/
  int NumOfEnzymes=/*atoi(argv[7])*/3;/*number of enzyme types - NumOfEnzymes*/
  int L=/*atoi(argv[8])*/70; /*length of RNAs - L*/
  double Empty=/*atof(argv[9])*/0.10; /* claim of empty: percentages of theoretical maximal metabolic efficiency within metabolic neighbourhood */
  double BoltzmannConst=atof(argv[6])/*0.30*/; /* constant of Boltzman distribution (c) (P=1/(1+exp(-c*Energy)), where p is [0.5,1] and Energy: Energy of RNA)*/
  double cc=/*atof(argv[11])*/10.0; /*constant value for the calculation of replication rate*/
  double  alpha=/*atof(argv[12])*/1.1; /*sub-additive effect on enzymatyc activities in promiscous enzyme*/
  long long int InitVOfRN=atoll(argv[7])/*0*/; /*random seed (0: is random seed, 
>0: seed)*/
  int MD=atoi(argv[8])/*0*/; /* Turn off/on MatrixDrawing function -- 0: turn off; 1: turn on*/
  double a=/*atof(argv[15])*/0.75; /* the intercept of the replication time function which depends on the length of sequence (1/(a+(b*L))) */
  double b=atof(argv[9]); /*1.0*/ /* the slope of the replication time function which depends on the length of sequence (1/(a+(b*L))) */
	double SUB=/*atof(argv[17]) */0.005; /* probability of SUBSTITUTION per base */
	double INS=/*atof(argv[18]) */0.0005; /* probability of INSERTION per base */
	double DEL=/*atof(argv[19]) */0.0005; /* probability of DELETION per base */
	int RandSeq=/*atoi(argv[20])*/1; /*0: initial seqences are defined; 1: initial sequences are random*/
	double BasicActivity=/*atof(argv[21]) */0.0; /*basic activitzy of RNA seqences if in their secondary structures can be found a same length loop like enzymatic loop*/
	int PartialDiffusion=atoi(argv[10]) /*0*/; /* PartialDiffusion: The Toffoli Margoulis mixes each particle 4 in during  one generation. In order to scaled it smaller steps we use this PartialDiffusion parameter (if D=1 !!!!): =4 only one steps/particule/generatation; =2 only two steps/particule/generatation and =0 only four steps/particule/generatation (default)*/
	int GridAverage=atoi(argv[11]) /*1*/; /* Turn on the calculation of AverageMetabolicEfficiency (1); Turn off the calculation of AverageMetabolicEfficiency (0);*/
	int Beolvas=atoi(argv[12]); /*0: It makes random initial population; 1: it reads replicators, pozitions, random seed and nd from "input_final_matrix.dat" and "RandomszamBeallitas.dat"; 10: it reads replicators from ListOfSequencePart1.fmdat */
	double bMax=atof(argv[13]); /* maximal value of b at the gradient*/
	int Step=atoi(argv[14]); /* number of time steps to reach bMax */
	double Cyclic=atof(argv[15]); /*0<x<1:The running is cyclic to make Survival-Died statistic, x the Critical number of Empty sites in the grid  or 0: ther is no Survival-Died statistic*/
	int NumOfActiveMetNeigh=atoi(argv[16])/*1*/; /*desired number of active metabolic neighbourhood in the initial (t=0) state*/

	printf(" *m=%d,*gt=%d,*wf=%d,*D=%d,*h=%d,r=%d,NumOfEnzymes=%d,L=%d,Empty=%f,*BoltzmannConst= %f, cc=%f, alpha=%f ,*InitVOfRN= %lld, *MD=%d,a=%f,* b=%f,SUB=%f, INS=%f,DEL=%f,RandSeq =%d , BasicActivity= %f,* PartialDiffusion =%d,* GridAverage=%d,* Beolvas =%d, * bMax=%f,* Step =%d,*Cyclic=%f , NumOfActiveMetNeigh= %d\n",m,gt,wf,D, h,r , NumOfEnzymes,L, Empty , BoltzmannConst, cc, alpha,InitVOfRN,MD,a, b,SUB, INS,DEL,RandSeq,BasicActivity,PartialDiffusion,GridAverage, Beolvas, bMax, Step,Cyclic,NumOfActiveMetNeigh);

	/*printf("INITVOfRN= %lld\n",InitVOfRN);*/
	/*exit(100);*/
	
	
	/*ENZYME activity 0.1*/
  /*char proba[3][51]={"GUCGAUCUCAAGCAGUUCGUGGCUAAUUUUCACGGCCUAGGAUUUCGGCA","AUGACGUCUCGCUUCGUCAAAGAACUGGUGCGCUGGCCUAGACAUGGCUG","UUGGUCUAGUACGGCGAUAUGUGGCUAGCUGUGUCAAUAGGAUAGACCGC"};*/
	/*ENZYME activity 1.0*/
  /*char proba[3][51]={"GAUUCCAUCUAACCCUGUGGCCGGCCCGCUAUAAAUCAGGGGGGAAGGUA","UUGUCAUAAACGCUUGAUGACACAAGAUAAGUGGUGGGCAAACCGCCAAG","UUGCUGUCCCGCGUGCAAAGCUGAAUCAGUAACACGCAGCCUGCGCGAGG"};*/
	 
	 
	 /*char proba[3][51]={"UAUU","ACGGGUA","ACAACAUCGAC"};*/
	 char BASES[5]="AUGC",*script, *TTT;
    
  /* MODEL VARIABLES */
  int NumOfMetNeigh=0, NumOfRepNeigh=0, mm=0,t=0,iteration=0, poz=0, PropOfRep=0,wf2=0,gt2=0,similarity=0,FH=0,AH=0,Repet;
	long long int RandNum;
	long long int nndd;
  int  *MetNeigh=NULL,*RepNeigh=NULL,*DiffNeigh=NULL,*tEmpty=NULL, PrintingProperties,ff,L1,num,OS=1;
  char  **matrix,*s,*sn; 
	int *Length=NULL,*LengthHist=NULL,*RandOrder=NULL;
  char *SeqComplete=NULL,base;
	double *claim=NULL, *results, **enzyme;
  double init=0.8,NumOfInitRep=0.0,p=0.0,sum=0.00,Exponent=0.0,RepRate=0.00, gsum=0.00,pDeath=0.00, TempEmpty=0.00, NumOfEmpty=0.00, ML=0.0,bMin=0,MetActivity=0.00;
  register int i,j,ii,jj,jjj;
	/*long long int il;*/
	
/** **/ /*m=25;gt=100;	*/
	bMin=b;
	gt2=gt;
	gt=gt2/*+(int)(gt*(double)0.001)*/;
	/*printf("m= %d\ngt=%d\ngt2=%d\nwf=%d\nD= %d\nh= %d\nr= %d\nNumOfEnzymes= %d\n",m,gt,gt2,wf,D,h,r,NumOfEnzymes);*/
	OS=OS;

		
	/*final=fopen("out_final_matrix.dat","w");
	fclose(final);*/
	E1E2E3=fopen("E1E2E3.dat","w");
	output=fopen("eredmenyek.dat","w");
	hist=fopen("length_histogram.dat","w");
	mut=fopen("error_mutation.dat","w");
	EnergyE1=fopen("EnergyE1.dat","w");
	EnergyE2=fopen("EnergyE2.dat","w");
	EnergyE3=fopen("EnergyE3.dat","w");
	EnergyE12=fopen("EnergyE12.dat","w");
	EnergyE13=fopen("EnergyE13.dat","w");
	EnergyE23=fopen("EnergyE23.dat","w");
	EnergyE123=fopen("EnergyE123.dat","w");
	EnergyFunctionless=fopen("EnergyFunctionless.dat","w");
	AverageMetabolicEfficiencyFile=fopen("AverageMetabolicEfficiencyFile.dat","w");
	
	
	
	mm=m*m;
	L1=L+1; /*lengt+1 to resolving memory*/
	Exponent=1.00/((double)NumOfEnzymes);
	NumOfInitRep=init*mm;
	/*printf("mm= %d, L1= %d, Exponent= %f, NumOfInitRep= %d\n",mm, L1, Exponent,(int)NumOfInitRep);*/
/*exit(100);*/
	PropOfRep=NumOfEnzymes+1; /* Energy + enzyme activities of replikators */
	PrintingProperties=66;
/* Printing variable: Time, Empty, number of replicator types (E1, E2, E3, E1E2, E1E3, E2E3, E1E2E3), their enzymatic activities(i*(NumOfEnzymes!/((NumOfEnzymes-i)!*i!))), SD of average of enzymatic activities and number of functionless enzyme, */
	/*for(i=1;i<=NumOfEnzymes;i++)
		PrintingProperties+=(i*((double)factorial(NumOfEnzymes)/(factorial(NumOfEnzymes-i)*factorial(i))));
	PrintingProperties=3+factorial(NumOfEnzymes)+(2*PrintingProperties);*/
	/*empty+all + number of combinatory of enzyme types + means of Enzymatic activity + SD-s of enzymatic activity + means of replication rate  + SD-s of replication rate + num of functionless replicator*/
	/*printf("factorial: %d, PrintingProperties: %d, PropOfRep= %d\n",factorial(NumOfEnzymes),PrintingProperties, PropOfRep);*/
	FH=mm-(int)(mm*Cyclic);
	AH=(int)(Cyclic*mm);
	Repet=1000; /*how many times try to creat initial matrix*/
	/*printf("AH= %d, FH= %d\n",AH,FH);*/
	if(InitVOfRN<0)
		InitVOfRN*=-1;
	else;



/** *********************************************************
							VARIABLES AND MEMORY ALLOCATION  
********************************************************** **/
/** Number of neighbours in neighbourhoods **/
	if(h>0)
    NumOfMetNeigh=pow(((h*2)+1),2);/*Moore neighbourhoods*/
  else NumOfMetNeigh=5; /*Neuman neighbourhoods*/
  if(r>0)
    NumOfRepNeigh=pow(((r*2)+1),2);/*Moore neighbourhoods*/
  else NumOfRepNeigh=5; /*Neuman neighbourhoods*/
  /*printf("NumOfMetNeigh= %d\nNumOfRepNeigh= %d\n",NumOfMetNeigh,NumOfRepNeigh);*/

/** Theoretical maximum of metabolic efficiency **/	
	tEmpty=(int*)calloc(NumOfEnzymes, sizeof(int));
	if(tEmpty==NULL) exit(1);
	/*printf("tEmpty: %d %d %d\n",tEmpty[0],tEmpty[1],tEmpty[2]);*/
	/*uniform distribution of metabolic replicators in the metabolic neighbourhood*/
	for(j=0;j<(NumOfMetNeigh-1);j++) 
		tEmpty[j%NumOfEnzymes]+=1;
	/*printf("tEmpty: %d %d %d\n",tEmpty[0],tEmpty[1],tEmpty[2]);*/
	TempEmpty=1.0;
	for(j=0;j<NumOfEnzymes;j++) 
		TempEmpty*=(tEmpty[j]*1.1); /*1.1 is the maximal enzymatic activity*/
/** Maximal Claim = maximal length-dependency * maximal kinetics constant of replication * maximal metabolic efficiency **/	
	TempEmpty=pow(TempEmpty,Exponent); /** Maximal Metabolic efficiency **/
	ML=(1.00/(a+(b*0))); /** maximal length-dependency **/
	RepRate=(1.0+(1.0/(1.0+exp(0))))*cc; /** maximal kinetics constant of replication **/
/*printf("Empty: %f, TempEmpty= %f, ML= %f, RepRate= %f\n",Empty, TempEmpty, ML, RepRate);*/
	Empty=Empty*TempEmpty*ML*RepRate;
/*printf("Empty= %f\n",Empty);*/
	free(tEmpty);


/** Memory reservation **/
  matrix=(char**) calloc(mm,sizeof(char*));
	if(matrix==NULL) exit(1);
	for(i=0;i<mm;i++)
		matrix[i]=(char*) calloc(L1,sizeof(char));
	
	for(i=0;i<mm;i++)
		matrix[i][0]='\0';
	
/*for(i=0;i<mm;i++)
	printf("%d) %s\n",i,matrix[i]);*/
		
	Length=(int*) calloc(mm,sizeof(int));
	if(Length==NULL) exit(1);
	
	/*printf("\nPropOfRep= %d\n", PropOfRep);*/
	
	enzyme=(double**) calloc(mm,sizeof(double*));
	if(enzyme==NULL) exit(1);
	for(i=0;i<mm;i++)
		enzyme[i]=(double*) calloc(PropOfRep,sizeof(double));
	
	/*enzyme[20][1]=5.0;*/
	/*for(i=0;i<mm;i++)
	{
		printf("%d: ",i);
		for(j=0;j<PropOfRep;j++)
			printf("%f ",enzyme[i][j]);
		printf("\n");
	}*/

/** **/	/*test_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0]);*/
	
	MetNeigh=(int*) calloc(m*m*NumOfMetNeigh,sizeof(int));
  if(MetNeigh==NULL) exit(1);
  RepNeigh=(int*) calloc(m*m*NumOfRepNeigh,sizeof(int));
  if(RepNeigh==NULL) exit(1);
  
  results=(double*) calloc(PrintingProperties,sizeof(double));
	if(results==NULL) exit(1);
	
  DiffNeigh=(int*) calloc(m*m*4,sizeof(int));
  if(DiffNeigh==NULL) exit(1);

/** NEIGHBOURHOODS **/	
	if(h>0)
		moore(m,&MetNeigh[0],h,NumOfMetNeigh);
  else neumann(m,&MetNeigh[0]);
  if(r>0)
		moore(m,&RepNeigh[0],r,NumOfRepNeigh);
  else neumann(m,&RepNeigh[0]);
  ToffoliNeigh(m,&DiffNeigh[0]);
	
	/*printf(" \n** Metabolic Neighbourhood **\n");
	for(i=0;i<mm;i++)
	{
		printf("%d: ",i);
		for(j=0;j<NumOfMetNeigh;j++)
			printf("%d ",MetNeigh[(i*NumOfMetNeigh)+j]);
		printf("\n");
	}
	printf(" \n** Replication Neighbourhood **\n");
	for(i=0;i<mm;i++)
	{
		printf("%d: ",i);
		for(j=0;j<NumOfRepNeigh;j++)
			printf("%d ",RepNeigh[(i*NumOfRepNeigh)+j]);
		printf("\n");
	}
	printf(" \n** Diffusion Neighbourhood **\n");
	for(i=0;i<mm;i++)
	{
		printf("%d: ",i);
		for(j=0;j<4;j++)
			printf("%d ",DiffNeigh[(i*4)+j]);
		printf("\n");
	}
exit(23);*/

/** ******************************************************* **/
/** **/ /*NumOfEmpty=printing(0,mm,&enzyme[0],NumOfEnzymes,&results[0],PrintingProperties,&matrix[0],BoltzmannConst,cc,a,b);*/
/** **/ /*exit(2225);*/

/** *********************************************************
											RANDOM PATTERN
********************************************************** **/
	/*printf("*****************\nRANDOM PATTERN\n*****************\n");*/
/** **/ /*exit(101);*/
/*test_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0]);*/
/*exit(101);*/
	/*for(i=0;i<mm;i++)
	{
		printf("%d: %s::%d (%1.4f %1.4f %1.4f %1.4f)\n",i,matrix[i],Length[i],enzyme[i][0],enzyme[i][1],enzyme[i][2],enzyme[i][3]);
	}*/
	
	
	if(Beolvas==0) /*Random replicator population*/
	{
		nd=0;
		if(InitVOfRN==0)
		{
			/*srand(time(NULL));*/
			fp = fopen("/dev/urandom", "r");
			OS=fread(&RandNum, sizeof(long long int),1, fp);
			fclose(fp);
			/*printf("RandNum= %d, fabs(RandNum)= %d\n",RandNum,(long)fabs(RandNum));*/
			seed(fabs(RandNum));
		}	    
		else 
		{
			seed(InitVOfRN);
			/*srand(InitVOfRN);*/
		}		
/*EREDETI RANDOM MINTAZAT KEZDET*/
		num=0;
		while(num==0)
		{/*while*/
			/*printf("RandomPattern elott: nd= %lld (%ld)\n",nd,InitVOfRN);*/
			RandomPattern(&matrix[0], &enzyme[0],&Length[0],NumOfInitRep,mm,BasicActivity,PropOfRep,RandSeq, L, BoltzmannConst,alpha);
			/*printf("RandomPattern utan: nd= %lld (%ld)\n",nd,InitVOfRN);*/
			
			
			for(i=1;i<m;i=i+3)
			{
				for(j=1;j<m;j=j+3)
				{
					ii=(i*m)+j;
					MetActivity=metabolism(ii,&MetNeigh[0],NumOfMetNeigh,&enzyme[0],Exponent,PropOfRep,BoltzmannConst,alpha, &Length[0]);
					if(MetActivity>0.0)
						num++;
				}
			}
			/*printf("num= %d\n",num);*/
			if(num==0)
			{
				for(i=0;i<mm;i++)
				{
					matrix[i][0]='\0';
					Length[i]=0;
					for(j=0;j<PropOfRep;j++)
						enzyme[i][j]=0.00;
				}
			}
			else ;
			/*if(num>0)
			{
				fpp=fopen("statisztika.dat","a");
				fprintf(fpp,"%ld %d\n",InitVOfRN,num);
				fflush(fpp);
				fclose(fpp);
				SeqList=fopen("ListOfSequence.dat","a");
				for(i=0;i<mm;i++)
				{
					if(Length[i]>0)
						fprintf(SeqList,"%s %d %1.4f %1.4f %1.4f %1.4f\n",matrix[i],Length[i],enzyme[i][0],enzyme[i][1],enzyme[i][2],enzyme[i][3]);
					else;
				}
				fflush(SeqList);
				fclose(SeqList);	*/	
/** **/			/*exit(54);*/
		/*}*/
		}/*while*/
/*EREDETI RANDOM MINTAZAT VEG*/
	}
	else /* Initailized replicator population*/
	{
		if(Beolvas==1)
		{
			/*printf("beolvasas elott: nd= %lld (%ld)\n",nd,InitVOfRN);*/
			beolvasas(&matrix[0], &enzyme[0],&Length[0],m,"input_final_matrix.dat",(int)NumOfInitRep,PropOfRep,L,similarity);
			/*printf("beolvasas utan: nd= %lld (%ld)\n",nd,InitVOfRN);*/
		}
		else if(Beolvas==10)
		{
			nd=0;
			if(InitVOfRN==0)
			{
			/*srand(time(NULL));*/
				fp = fopen("/dev/urandom", "r");
				OS=fread(&RandNum, sizeof(long long int),1, fp);
				fclose(fp);
				/*printf("RandNum= %d, fabs(RandNum)= %d\n",RandNum,(long)fabs(RandNum));*/
				seed(fabs(RandNum));
				/*rn=randd(RandNum);*/
			}	    
			else 
			{
				seed(InitVOfRN);
				/*srand(InitVOfRN);*/
				/*rn=randd(InitVOfRN);*/
			}
			
			OS=system("chmod u+x FileTest.sh");
			OS=system("./FileTest.sh");
			s=(char*)calloc(1000,sizeof(char));
			fp=fopen("FileTestRes.dat","r");
			OS=fscanf(fp,"%s\n",s);
			/*printf("%s\n",s);*/
			fclose(fp);
		
			similarity=0;
			similarity=strcmp(s,"TRUE");
			free(s);
			
			if(similarity!=0)
			{
				OS=system("rm -f NamedPipe");			
			
				s=(char*)calloc(1000,sizeof(char));
				sn=(char*)calloc(1000,sizeof(char));
				OS=system("mkfifo NamedPipe"); /*Nevesitett pipe file eloallitas*/
				OS=sprintf(sn,"%lld",InitVOfRN);
				strcpy(s,"yes ");
				strcat(s,sn);
				strcat(s," > NamedPipe &");
				/*printf("s= %s\n",s);*/ /*a "yes INITVOfRN > NamedPipe" megy be a nevesitett pipe-ba*/
				OS=system(s);
				free(s);
				free(sn);
		
				s=(char*)calloc(1000,sizeof(char));
				strcpy(s,"shuf --random-source=NamedPipe ");
				strcat(s,"ListOfSequencePart1.fmdat");
				strcat(s," > temp");
				/*printf("s= %s\n",s);*/ /*ez jon ki a nevesitett pipe-bol*/
				OS=system(s);	
				OS=system("pkill -9 yes");
				free(s);
			}
			
			num=0;
			for(jj=0;jj<Repet;jj++)
			{
				/*printf("beolvasas elott: nd= %lld (%ld)\n",nd,InitVOfRN);*/
				beolvasas(&matrix[0], &enzyme[0],&Length[0],m,"RandSeqMatrix.dat",(int)NumOfInitRep,PropOfRep,L,similarity);
				/*printf("beolvasas utan: nd= %lld (%ld)\n",nd,InitVOfRN);*/
				/*test_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0]);*/
/*exit(145);*/
				for(i=1;i<m;i=i+3)
				{
					for(j=1;j<m;j=j+3)
					{
						ii=(i*m)+j;
						/*printf("i= %d, j= %d, ii= %d\n",i,j,ii);*/
						MetActivity=metabolism(ii,&MetNeigh[0],NumOfMetNeigh,&enzyme[0],Exponent,PropOfRep,BoltzmannConst,alpha, &Length[0]);
						if(MetActivity>0.0)
							num++;
					}
				}
				/*printf("num= %d\n",num);*/
				if(num!=NumOfActiveMetNeigh)
				{
					for(i=0;i<mm;i++)
					{
						matrix[i][0]='\0';
						Length[i]=0;
						for(j=0;j<PropOfRep;j++)
							enzyme[i][j]=0.00;
					}
					OS=system("rm -f RandSeqMatrix.dat");
					num=0;
				}
				else 
				{
					final_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0],t, InitVOfRN,"RandSeqMatrix.dat",&MetNeigh[0],NumOfMetNeigh,Exponent,PropOfRep,BoltzmannConst,alpha);
					break;
				}
				/*if(num>0)
				{
					fpp=fopen("statisztika.dat","a");
					fprintf(fpp,"%ld %d\n",InitVOfRN,num);
					fflush(fpp);
					fclose(fpp);
					SeqList=fopen("ListOfSequence.dat","a");
					for(i=0;i<mm;i++)
					{
						if(Length[i]>0)
							fprintf(SeqList,"%s %d %1.4f %1.4f %1.4f %1.4f\n",matrix[i],Length[i],enzyme[i][0],enzyme[i][1],enzyme[i][2],enzyme[i][3]);
						else;
					}
					fflush(SeqList);
					fclose(SeqList);	*/	
/** **/		/*exit(54);*/
				/*}*/		
			}			
			if(jj<Repet)
			{
				fp=fopen("InitialMatrixTest.dat","w");
				fprintf(fp,"%s\n","SUCCESS");
				fflush(fp);
				fclose(fp);
			}
			else
			{
				fp=fopen("InitialMatrixTest.dat","w");
				fprintf(fp,"%s\n","FAILED");
				fflush(fp);
				fclose(fp);			
				exit(45);
			}
		}
	}
  /*for(i=0;i<10;i++)
	{
		printf("%d %s %d %1.4f %1.4f %1.4f %1.4f\n",i,matrix[i],Length[i],enzyme[i][0],enzyme[i][1],enzyme[i][2],enzyme[i][3]);
	}*/


	
	
/** INITIALIZATION OF RANDOM NUMBER GENERATOR **/
/*printf("INITVOfRN= %ld, Beolvas= %d\n",InitVOfRN, Beolvas);*/
	if(Beolvas==10) /*Random replicator population*/
	{
		nd=0;
		seed(InitVOfRN);
		/*srand(InitVOfRN);*/
	}
	else if(Beolvas==1) 
	{
		/*RandNumberBeallitashoz=fopen("RandomszamBeallitas.dat","r");
		OS=fscanf(RandNumberBeallitashoz,"%ld %lld\n",&InitVOfRN,&nndd);
		fclose(RandNumberBeallitashoz);	*/
		/*printf("InitVOfRN= %ld, nndd= %lld\n",InitVOfRN,nndd);*/
		seed(InitVOfRN);		
	}
	else;
/*printf("seed initializalas: nd= %lld (%ld)\n",nd,InitVOfRN);*/

/*printf("randl()= %ld\n",randl(12));
printf("randl()/12= %f\n",(double)randl(12)/12.00);
printf("randd()= %f\n",randd());*/

	
/** ******************************************************* **/
	t=0;
	NumOfEmpty=printing(t,mm,&enzyme[0],NumOfEnzymes,&results[0],PrintingProperties, &matrix[0],BoltzmannConst,cc,&Length[0],a,b);
	
	/*ComplementerEnzymeActivityMatrix(t,m,NumOfEnzymes,L,BasicActivity, 
&matrix[0],&enzyme[0],&Length[0],BoltzmannConst,alpha);*/

/** **//*exit(12);*/
	if(MD==1)
		MatrixDrawing(&enzyme[0],m,t);
		
	fprintf(output,"%lf ",(double)t);
	for(j=0;j<PrintingProperties;j++)
	{
		fprintf(output,"%lf ",results[j]);
		
	}
	fprintf(output,"\n");
	fflush(output);

/*exit(12);*/

	LengthHist=(int*)calloc(L1,sizeof(int));
	if(LengthHist==NULL) {printf("Nem lehet memoriat foglalani!\n");exit(1);}	
			
	for(j=0;j<mm;j++)
		LengthHist[Length[j]]+=1;
		
	fprintf(hist,"%d ",t);
	
	for(j=0;j<L1;j++)
	{
		
		fprintf(hist,"%d ",LengthHist[j]);
	}
	
	fprintf(hist,"\n");
	fflush(hist);
	free(LengthHist);
	
	if(NumOfEmpty==mm)
	{
		fclose(output);
		fclose(hist);
		fclose(E1E2E3);fclose(EnergyFunctionless);fclose(EnergyE1);fclose(EnergyE2);fclose(EnergyE3);fclose(EnergyE12);fclose(EnergyE13);fclose(EnergyE23);fclose(EnergyE123);fclose(AverageMetabolicEfficiencyFile);
		fclose(mut);		
		
		for(i=0;i<mm;i++)
		{
			free(matrix[i]);
			free(enzyme[i]);
		}
		free(enzyme);
		free(matrix);
		free(Length);
		free(MetNeigh);
		free(RepNeigh);
		free(results);
		free(DiffNeigh);	
		
		exit(1);
	}
	final_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0],t, InitVOfRN,"_out_final_matrix.fmdat",&MetNeigh[0],NumOfMetNeigh,Exponent,PropOfRep,BoltzmannConst,alpha);
	
/*exit(22);*/
/** *********************************************************
											ITERATION
********************************************************** **/	
	/*if(Beolvas==1) 
	{
		printf("1.: nd= %ld (%ld)\n",nd,InitVOfRN);
		seed((long)InitVOfRN);
		printf("2.: nd= %ld (%ld)\n",nd,InitVOfRN);
		for(il=0;il<nndd;il++)
			randl(2);
		printf("3.: nd= %ld (%ld)\n",nd,InitVOfRN);
	}
	else;*/


	for(t=1;t<=gt;t++)
	{/*TIME*/
		/*printf("time: %d\t",t);*/
		/*printf("gt elejen:t= %d, nd= %ld (%ld)\n",t,nd,(long)InitVOfRN);*/
		/*if(t==1)
			test_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0]);*/
		
		if(Step>0)
		{
			if((t>=1)&&(t<=(Step+1)))
			{
				b=b_valtozas(bMax,bMin,t-1,Step);
			}
		}
		/*printf("%d. : %f\n",t,b);*/
/** **/ /*exit(12);*/

		for(iteration=0;iteration<mm;iteration++)
/** **/ /*for(iteration=0;iteration<1;iteration++)*/
		{/*ITERATION*/
			/*printf("time= %d: iteration= %d\n",t,iteration);*/
			
			poz=(int)randl(mm);
			/*printf("## %d. poz helyen(%d): t= %d, nd= %ld\n",iteration,poz,t,nd);*/
			/*if((Beolvas==0)&&(t==8))
			{
				printf("### %d. poz helyen(%d): t= %d, nd= %ld\n",iteration,poz,t,nd);
				if(iteration==0)
					test_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0]);
			}
			else if((Beolvas>0)&&(t==1))
			{
				printf("### %d. poz helyen(%d): t= %d, nd= %ld\n",iteration,poz,t,nd);
				if(iteration==0)
					test_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0]);
			}*/
			
			

/** PROGRAM KESZITESHEZ***/			
/*If InitVOfRN=42*/
/*poz=5;*/
/*matrix[poz][0]='\0';
for(i=0;i<PropOfRep;i++)
	enzyme[poz][i]=0.0;
Length[poz]=0;*/
/*Length[15]=20;
strcpy(matrix[15],"AGGCAAGGCAAGGCAAGGCA");
matrix[15][21]='\0';*/
/*enzyme[0][1]=1.10;
enzyme[1][2]=1.10;
enzyme[2][3]=1.10;*/
/*enzyme[15][3]=0.40;*/
/*enzyme[5][1]=0.4;
enzyme[18][3]=1.1;
enzyme[18][2]=0.4;*/
/** **/
/*test_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0]);
printf("poz: %d %s::%d (",poz, matrix[poz],Length[poz]);
for(ii=0;ii<PropOfRep;ii++)
	printf("%f ",enzyme[poz][ii]);
printf(")\n");*/

/** DEATH **/	
			if(Length[poz]>0)
			{
				/*printf("POZ is not zero\n");*/
				p=randd();
				pDeath=0.1+((enzyme[poz][0]/25.0)*(0.90-0.1));/** From [0.00, 25.0] to [0.00, 0.90] **/
/** **/ /*p=0.004563;*/
/*printf("p: %f, enzyme[%d][0]= %f, pDeath= %f, (1-pDeath)/100= %f\n",p,poz,enzyme[poz][0],pDeath,(1.00-pDeath)/100.0);*/
/*exit(12);*/

				if(p<((1.00-pDeath)/100.0))
				{
					/*printf("DIE OUT\n");*/
					matrix[poz][0]='\0';
					for(i=0;i<PropOfRep;i++)
						enzyme[poz][i]=0.0;
					Length[poz]=0;
					/*printf("\n");*/
				}
				else /*printf("SURVIVE\n")*/;
/** **/	/*test_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0]);*/
				
				/*printf("AFTER ITERATION: %d\n",RepNeigh[(poz*NumOfRepNeigh)+0]);
				printf("%s ",matrix[poz]);
				for(ii=0;ii<PropOfRep;ii++)
					printf("%f ",enzyme[poz][ii]);
				printf("\n");*/

			}
/**  **/
			else
			{ /* competion for empty site */
					/*printf("POZ is zero\n");*/
/*exit(15);*/
/** METABOLISM 

A SZERKEZETI STABILITÁSTOL FÜGG:
1) MÁSOLHATÓSÁG: LAZÁBB SZERKEZET NAGYOBB VALOSZINUSEGGEL MÁSOLÓDIK (P=1/(1+EXP(c*E)). EZ VAN RepRate-BA BEÉPÍTVE  
2) ENZIMATIKUS AKTIVITIAS: LAZABB SZERKEZET KONYEBBEN ÁTMEGY OLYAN ÁLLAPOTBA AMI NEM ENZIMATIKUSAN AKTÍV (P=1/(1+EXP(-c*E)). EZ A MATABOLISM FUGGVÉNYBEN VAN. 
3) MÁSOLÁS IDEJE FÜGG A SZEKVENCIA HOSSZATOL: 1/(a+b*L)

**/			
/*printf("NumOfRepNeigh= %d\n",NumOfRepNeigh);*/

/** **/				/*rand();*/
/*test_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0]);*/

				claim=(double*)calloc(NumOfRepNeigh,sizeof(double));
					if(claim==NULL) exit(1);
				RandOrder=(int*) calloc(NumOfRepNeigh,sizeof(int));
					if(RandOrder==NULL) exit(1);
					
				for(i=0;i<NumOfRepNeigh;i++)
					RandOrder[i]=-100;
/*for(i=0;i<NumOfRepNeigh;i++)
	printf("claim[%d]= %f RandOrder[%d]= %d\n",i,claim[i],i,RandOrder[i]);*/
				
				i=0;
				while(i<NumOfRepNeigh)
				{
					ii=(int)randl(NumOfRepNeigh);
/*printf("i= %d, ii= %d\t",i, ii);
exit(11);*/
					if(RandOrder[ii]==-100)
					{
						RandOrder[ii]=i;
						/*printf("RandOrder[%d]= %d\n",ii,RandOrder[ii]);*/
						i++;
					}
					/*printf("\n");*/
				}
	

/*for(i=0;i<NumOfRepNeigh;i++)
	printf("RandOrder[%d]= %d\n",i,RandOrder[i]);*/
/*printf("*** claim[%d]= %f *** \n",RandOrder[0],claim[]);*/				

				for(i=0;i<NumOfRepNeigh;i++)
				{
					/*printf("i= %d\n",i);*/
					if(RandOrder[i]==0)
					{
						claim[i]=Empty;
/*printf("*** claim[%d]= %f *** \n",i,claim[i]);*/
					}
					else
					{
					
						ii=RepNeigh[(poz*NumOfRepNeigh)+RandOrder[i]];
/*printf("ii= %d\n",RepNeigh[(poz*NumOfRepNeigh)+RandOrder[i]]);
printf("%d: %s (%f %f %f %f)::%d\n",ii,matrix[ii],enzyme[ii][0],enzyme[ii][1],enzyme[ii][2],enzyme[ii][3],Length[ii]);*/


/*!!!*/			if(Length[ii]>0)
/*!!!*/			{
							RepRate=(1.0+(1.0/(1.0+exp(BoltzmannConst*enzyme[ii][0]))))*cc;/* replication rate depends on the stability of replicator: instable structure -- more probability for replication, stable structure -- less probability for replication. Probability is calculated by Boltzmann distribution, 10 IS PULL AWAY THE AXIS Y */
						
/*enzyme[15][1]=0.4;*/
				/** Claim= length-dependency * kinetics constant of replication * metabolic efficiency **/	
/*printf("*** claim[%d]= %f *** \n",i,claim[i]);*/
				claim[i]=(1.00/(a+(b*Length[ii])))*RepRate*metabolism(ii,&MetNeigh[0],NumOfMetNeigh,&enzyme[0],Exponent,PropOfRep,BoltzmannConst,alpha, &Length[0]);
				
/*printf("*** claim[%d]= %f *** \n",i,claim[i]);
printf("Lenght dependency: %f\nRepRate: %f\nClaim[%d]= %f\n",(1.00/(a+(b*Length[ii]))),RepRate,i,claim[i]);*/
		
/*!!!*/			}
/*!!!*/			else claim[i]=0.0;	
/*printf("claim[%d]= %f\n",i,claim[i]);*/
					}
/** **/			
				}

/** **/	/*exit(111);*/
				
/** ***************************************************
  CHOISE OF A REPLICATOR FOR REPLICATION
******************************************************/
        sum=gsum=0.00;
        for(i=0;i<NumOfRepNeigh;i++)
				{
/*printf("C: claim[%d]= %f\n",i,claim[i]);*/
					sum+=claim[i];
				}

				p=randd();
/**!!!**/	/*p=0.66;*/
/*printf("Sum of calim: %f\nProbability of choice: %f\n",sum,p);*/
/*exit(11);*/
     
        for(i=0;i<NumOfRepNeigh;i++)
        {
          gsum+=claim[i];
/*printf("%d: claim[%d]: %f, gsum:  %f, gsum/sum: %f, p: %f\n",RepNeigh[(poz*NumOfRepNeigh)+RandOrder[i]],i,claim[i],gsum,gsum/sum,p);*/
          if(p<(gsum/sum))
          {
						ii=RepNeigh[(poz*NumOfRepNeigh)+RandOrder[i]];
												
/*test_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0]);*/
						if(Length[ii]>0)
							/*strcpy(matrix[poz],matrix[ii]);*/
							complementer(ii,poz,&matrix[0], Length[ii]);
						else;
						/*for(jj=0;jj<PropOfRep;jj++)
							enzyme[poz][jj]=enzyme[ii][jj];*/
						Length[poz]=Length[ii];
/*test_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0]);*/
            break;
						

          }
          else;
        }
/** **/ /*exit(216); */ 
        /*printf("%d -> %d\nNEW: %s::%d (%f %f %f %f)\n",RepNeigh[(poz*NumOfRepNeigh)+RandOrder[i]],poz,matrix[poz],Length[poz],enzyme[poz][0],enzyme[poz][1],enzyme[poz][2],enzyme[poz][3]);*/
				
				/*printf("\n\n%s\n%s\n\n",matrix[ii],matrix[poz]);*/
				
/** **/ /*exit(216); */

/**  **/free(claim);
				free(RandOrder);
				/*claim=RandOrder=NULL;*/
		
		
/** MUTATION **/	
				if(Length[poz]>0)
				{/*mutation*/
				
					/*printf("Mutation\n");*/
					/*printf("L(%d)<L1(%d)\n",L,L1);*/
				
					num=0;
					while(num<10)
					{
						/*printf("num= %d\n",num);*/
						SeqComplete=(char*)calloc(2*L1,sizeof(char));
						if(SeqComplete==NULL) exit(1);
						
						jjj=0;
						for(j=0;j<=Length[poz]-1;j++)
						{
/** **/				p=randd();
/*printf("%d: p= %f, SUB= %f INS= %f, DEL= %f\n",j,p,SUB,INS,DEL);*/
/*exit(12);*/

							if(p<SUB)
							{
								do base = BASES[(int)randl(4)]; 
								while(base == matrix[poz][j]);
								SeqComplete[jjj] = base;
							
/*printf("%d. %c-> %c\n",j,matrix[poz][j],SeqComplete[jjj]);*/
/*exit(12);*/
								jjj++;
							}
							else if(p<(SUB+INS))
							{
								if((int)randl(2)==1)
								{
									SeqComplete[jjj]=matrix[poz][j];
									SeqComplete[jjj+1]=BASES[(int)randl(4)];
/*printf("INSERTION Behind at %d (%c)\n",j,SeqComplete[jjj+1]);*/


								}
								else
								{
									SeqComplete[jjj]=BASES[(int)randl(4)];
									SeqComplete[jjj+1]=matrix[poz][j];
/*printf("INSERTION Before at %d (%c)\n",j,SeqComplete[jjj]);*/
								}
								jjj+=2;
/*exit(12);*/
							}
							else if(p<(SUB+INS+DEL))
							{
/*printf("DELETION at %d\n",j);*/
								;
							}
							else 
							{
								SeqComplete[jjj]=matrix[poz][j];
								jjj++;
							}
						}
						SeqComplete[jjj]='\0';
/*printf("T: %s::%d\nO: %s::%d\n",matrix[poz],Length[poz],SeqComplete,strlen(SeqComplete));*/
						if((strlen(SeqComplete)>L)||(strlen(SeqComplete)<10))
						{
/*printf("Length of SeqComplete= %d\n",strlen(SeqComplete));
printf("t= %d, iteration= %d, poz= %d, num= %d\n",t, iteration, poz, num);*/
							fprintf(mut,"%d %d %d %d\n",t, iteration, poz, num);
							fflush(mut);
							free(SeqComplete);
							num++;
						}
						else 
						{
							num=10;
							Length[poz]=strlen(SeqComplete);
							strcpy(matrix[poz],SeqComplete);
/*printf("matrix[%d]\t= %s\nSeq\t\t= %s Length[%d]= %d \n ",poz,matrix[poz],SeqComplete,poz,Length[poz]);*/
							free(SeqComplete);
						}
					}
					ff=foldol(enzyme[poz],matrix[poz],Length[poz],BasicActivity,BoltzmannConst,alpha);
					if(ff!=0)
					{
						for(jj=0;jj<PropOfRep;jj++)
							enzyme[poz][jj]=0.00;
					}		
					
				
/*printf("mutacio vege\n");*/

				} /*muatation*/	
/*printf("mutacio utan\n");	*/			
				

/*printf("matrix[%d]= %s::%d (%f %f %f %f)\n ",poz,matrix[poz],Length[poz], enzyme[poz][0],enzyme[poz][1],enzyme[poz][2],enzyme[poz][3]);*/
/*test_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0]);*/

			}/* competion for empty site */
/*printf("Out of update\n");
exit(12);*/
			
/** ***************************************************
           DIFFUSION
******************************************************/
			/*for(i=0;i<mm;i++)
				printf("(DIFFUSION)%d: %s (%1.4f %1.4f %1.4f %1.4f)::%d\n",i,matrix[i],enzyme[i][0],enzyme[i][1],enzyme[i][2],enzyme[i][3],Length[i]);*/
/*printf("Before diffusion\n");
test_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0]);*/
			if(D>1) /*more diffusion steps in one generation (D, in each particule move D*4 steps)*/
			{
				for(i=1;i<=D;i++)
					diffusion(m,&DiffNeigh[0],&matrix[0],&enzyme[0],PropOfRep,&Length[0]);
			}
      else if((D==1) && (PartialDiffusion==0)) /*1 diffusion step in one generation (D=1, in each particule move 4 steps)*/
					diffusion(m,&DiffNeigh[0],&matrix[0],&enzyme[0],PropOfRep,&Length[0]);
			else if((D==1) && (PartialDiffusion>0)) /*few diffusion steps in one generation (D=1, in each particule move 4 * 1/PartialDiffusion: 1/4 or 1/2)*/
			{
				if((iteration%PartialDiffusion)==0)
					diffusion(m,&DiffNeigh[0],&matrix[0],&enzyme[0],PropOfRep,&Length[0]);
				else;
			}
			else; /* No diffusion D=0*/
        /*printf("After diffusion\n");*/
        /*MatrixPrinting(&matrix[0], m,&k[0],&impair[0]);*/
/*exit(11);*/
      /*printf("\n");
      for(i=0;i<mm;i++)
				printf("%d: %s (%1.4f %1.4f %1.4f %1.4f)::%d\n",i,matrix[i],enzyme[i][0],enzyme[i][1],enzyme[i][2],enzyme[i][3],Length[i]);*/
/*printf("After diffusion\n");
test_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0]);*/
/*exit(11);*/
/*printf("%d iteracio vege t= %d, nd= %ld\n",iteration,t,nd);*/
		}/*ITERATION*/
/*printf("%d iteracio utan t= %d, nd= %ld\n",iteration,t,nd);*/

		/*if(t==1)
		{
			nd=2137;
			bubu=randl(12558);
			printf("bubu= %ld; nd= %ld\n",bubu,nd);
		}*/
/** ***************************************************
           SAVE DATA
******************************************************/
		if((t<=10000)||(t>=(gt-10000)))
			wf2=1;
		else wf2=wf;
		/*printf("\n\n\nwf2= %d\n\n\n",wf2);*/
		
		
		/*if((t%1000)==0)
		{
			 ComplementerEnzymeActivityMatrix(t,m,NumOfEnzymes,L,BasicActivity, &matrix[0],&enzyme[0],&Length[0],BoltzmannConst,alpha);
			
		}*/

		if((t%wf2)==0)
    {
      /*printf("t= %d, gt= %d\n",t,gt);*/
			if(gt>=10)
			{
				ii=(int)(((double)t/(double)gt)*100.0);
				/*printf("t= %d, gt= %d, ii= %d\n",t,gt,ii);*/
				if(((ii%10)==0)&&(t%((int)((double)gt/10.0))==0))
					printf("%d%% \n",ii);
				else;
			}
			else;
      
			NumOfEmpty=printing(t,mm,&enzyme[0],NumOfEnzymes,&results[0],PrintingProperties,&matrix[0],BoltzmannConst,cc,&Length[0],a,b);
			/*printf("TIME: %d, NumOfEmpty= %f\n",t,NumOfEmpty);*/
			if(MD==1)
				MatrixDrawing(&enzyme[0],m,t);
			
			fprintf(output,"%lf ",(double)t);
			/*printf("%f ",(double)i*wf);*/
			for(j=0;j<PrintingProperties;j++)
			{
				fprintf(output,"%lf ",results[j]);
				/*printf("%f ",results[i][j]);*/
			}
			fprintf(output,"\n");
			fflush(output);
			
			LengthHist=(int*)calloc(L1,sizeof(int));
			if(LengthHist==NULL) {printf("Nem lehet memoriat foglalani!\n");exit(1);}	
			
			for(j=0;j<mm;j++)
				LengthHist[Length[j]]+=1;
			
			fprintf(hist,"%d ",t);
			/*printf("%d ",t);*/
			for(j=0;j<L1;j++)
			{
				/*printf("%d ",LengthHist[j]);*/
				fprintf(hist,"%d ",LengthHist[j]);
			}
			/*printf("\n");*/
			fprintf(hist,"\n");
			fflush(hist);
			
			free(LengthHist);			

			/*if(NumOfEmpty==mm)*/
			/*printf("NumOfEmpty= %f, AH= %d, FH= %d\n",NumOfEmpty,AH,FH);*/
			if((NumOfEmpty<=AH)||(NumOfEmpty>=FH))
			{
				fclose(output);
				fclose(hist);
				fclose(E1E2E3);fclose(EnergyFunctionless);fclose(EnergyE1);fclose(EnergyE2);fclose(EnergyE3);fclose(EnergyE12);fclose(EnergyE13);fclose(EnergyE23);fclose(EnergyE123);fclose(AverageMetabolicEfficiencyFile);
				fclose(mut);		
		
				for(i=0;i<mm;i++)
				{
					free(matrix[i]);
					free(enzyme[i]);
				}
				free(enzyme);
				free(matrix);
				free(Length);
				free(MetNeigh);
				free(RepNeigh);
				free(results);
				free(DiffNeigh);	

				exit(1);
			}
			
			if(GridAverage==1)
			{
				/*test_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0]);*/
				AverageMetabolicEfficiency(t,mm, &matrix[0], &MetNeigh[0],NumOfMetNeigh,&enzyme[0],Exponent, PropOfRep,BoltzmannConst,alpha, &Length[0], &RepNeigh[0],NumOfRepNeigh);
			}
			else;
			
						
			
		}
		
		if(((Beolvas==0)||(Beolvas==1))&&((t%10000)==0)) /* Saving replicator population at a given time*/
		{	
			/*final_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0],t, InitVOfRN,"_out_final_matrix.fmdat");*/
			final_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0],t, InitVOfRN,"_out_final_matrix.fmdat",&MetNeigh[0],NumOfMetNeigh,Exponent,PropOfRep,BoltzmannConst,alpha);
			
			
			script=(char*) calloc(1000,sizeof(char));
			if(script==NULL) exit(1);
	
			TTT=(char*) calloc(1000,sizeof(char));
			if(TTT==NULL) exit(1);

			/*printf("_Complementer_enzyme_activity_matrix.dat\n");
			strcpy(script,"tar -czvf ");
			sprintf(TTT,"%d",t);
			strcat(script,TTT);
			strcat(script,"_Complementer_enzyme_activity_matrix.tar.gz *_Complementer_enzyme_activity_matrix.dat");*/

/*printf("time= %d, tt= %s\n",LocalTime,tt);*/
			
/*printf("time= %d, tt= %s\n",LocalTime,tt); */
			
	/*printf("%s\n",tt);*/
			system(script);
			
			free(TTT);
			free(script);
			
			
			/*printf("Kimentes utan: t= %d, nd= %ld\n",t,nd);
		
			printf("Kimentes utan: t= %d, nd= %ld\n",t,nd);
			printf("gt utan: t= %d, nd= %ld\n\n",t,nd);*/
			/*test_printing(m,L1,PropOfRep,&matrix[0],&Length[0], &enzyme[0]);*/
		}
	}/*TIME*/
/*exit(11);*/
/** ******************************************************* **/

	fclose(output);
	fclose(hist);

fclose(E1E2E3);fclose(EnergyFunctionless);fclose(EnergyE1);fclose(EnergyE2);fclose(EnergyE3);fclose(EnergyE12);fclose(EnergyE13);fclose(EnergyE23);fclose(EnergyE123);
	fclose(mut);fclose(AverageMetabolicEfficiencyFile);		


	for(i=0;i<mm;i++)
	{
		free(matrix[i]);
		free(enzyme[i]);
	}
	free(enzyme);
	free(matrix);
	free(Length);
	free(MetNeigh);
	free(RepNeigh);
	free(results);
	free(DiffNeigh);	

/*printf("vege\n");*/
	return 0;
}

void test_printing(int GridSize,int SeqLenght,int Properties,char **Grid,int * RepLength, double **Activities)
{
	int i, j;
	/*printf ("IN TEST_PRINTING\n");*/
	
	for(i=0;i<GridSize;i++)
	{
		for(j=0;j<GridSize;j++)
			printf("%d ",RepLength[(i*GridSize)+j]);
		printf("\t\t");
		for(j=0;j<GridSize;j++)
			printf("%lf ",Activities[(i*GridSize)+j][0]);
		printf("\n");
	}
	printf("\n\n");
	for(i=0;i<GridSize;i++)
	{
		for(j=0;j<GridSize;j++)
			printf("%lf ",Activities[(i*GridSize)+j][1]);
		printf("\t");
		for(j=0;j<GridSize;j++)
			printf("%lf ",Activities[(i*GridSize)+j][2]);
		printf("\t");
		for(j=0;j<GridSize;j++)
			printf("%lf ",Activities[(i*GridSize)+j][3]);
		printf("\n");
		
	}
	
	for(i=0;i<GridSize*GridSize;i++)
	{
		printf("%d: %s::%d (%lf %lf %lf %lf)\n",i,Grid[i],RepLength[i],Activities[i][0],Activities[i][1],Activities[i][2],Activities[i][3]);
	}

}

void final_printing(int GridSize,int SeqLenght,int Properties,char **Grid,int * 
RepLength, double **Activities, int LocalTime, long long int IVOfRN, char* 
FileName, int *MetNeigh, int NumOfMNeigh, double Exponent, int POR, double BC, double sigma)
{
	int i,similarity;
	char *st=NULL;
	double met;
	
	/*printf ("IN FINAL_PRINTING\n");*/
	
	st=(char*) calloc(1000,sizeof(char));
		if(st==NULL) exit(1);
	
	similarity=strcmp(FileName,"_out_final_matrix.fmdat");
	/*printf("similarity= %d\n",similarity);*/
	if(similarity==0)
	{
		/*printf("time= %d, st= %s\n",LocalTime,st);*/
		sprintf(st,"%d",LocalTime);
/*printf("time= %d, tt= %s\n",LocalTime,tt); */
		strcat(st,FileName);
	/*printf("%s\n",tt);*/
	
		RandNumberBeallitashoz=fopen("OUT_RandomszamBeallitas.dat","w");
		fprintf(RandNumberBeallitashoz,"%lld %lld\n",IVOfRN,nd);
		fclose(RandNumberBeallitashoz);
	
	}
	else strcpy(st,FileName);
	
	final=fopen(st,"w");
	for(i=0;i<GridSize*GridSize;i++)
	{
		met=metabolism(i,&MetNeigh[0],NumOfMNeigh,&Activities[0],Exponent,POR,BC,sigma,&RepLength[0]);
		if(RepLength[i]>0)
		{
			fprintf(final,"%s %d %lf %lf %lf %lf %f\n",Grid[i],RepLength[i],Activities[i][0],Activities[i][1],Activities[i][2],Activities[i][3],met);
		}
		else
		{
			fprintf(final,"%d %d %lf %lf %lf %lf\n",0,RepLength[i],Activities[i][0],Activities[i][1],Activities[i][2],Activities[i][3]);
		}
	}
	
	fflush(final);
	fclose(final);
		
	free(st);

}



