#include  "MRM_RNA_complementer.h"

void RandomPattern(char **grid, double **activity, int *Hossz, double InitialRep,int size , double BA, int POR, int RS,int MaxL)
{
/**
	**grid --  the matrix (matrix)
	**activity -- enzymatic activities and energy of replicators (enzyme)
	*Hossz -- maximal length of replicators (Length)
	InitialRep -- number of replicators on the grid at the beggining of simulation	(NumOfInitRep)
	size -- siz of matrix (mm)
	BA -- basic activitis of enzymes (BasicActivity)
	POR -- number of features of replicators (activity and energy, PropOfRep)
	RS -- the initial population is a reandom population or not (RandSeq)
	maxL -- maximal length of replicators (L)
**/
	
	int i,j,jj, poz;
	long int ll;
	double ff;
	/*char proba[3][51]={"GUCGAUCUCAAGCAGUUCGUGGCUAAUUUUCACGGCCUAGGAUUUCGGCA","AUGACGUCUCGCUUCGUCAAAGAACUGGUGCGCUGGCCUAGACAUGGCUG","UUGGUCUAGUACGGCGAUAUGUGGCUAGCUGUGUCAAUAGGAUAGACCGC"};*/
	/*ENZYME activity 1.0*/
  char proba[3][51]={"GAUUCCAUCUAACCCUGUGGCCGGCCCGCUAUAAAUCAGGGGGGAAGGUA","UUGUCAUAAACGCUUGAUGACACAAGAUAAGUGGUGGGCAAACCGCCAAG","UUGCUGUCCCGCGUGCAAAGCUGAAUCAGUAACACGCAGCCUGCGCGAGG"};
	/*char proba[3][51]={"UAUU","ACGGGUA","ACAACAUCGAC"};*/
	
	for(i=0;i<(int)InitialRep;i++)
  {
		
/*if(i==4) exit(12);*/
		poz=randl(size);
/*poz=20;*/
/*printf("poz= %d\n",poz);*/
/*exit(111);*/
		
		if(Hossz[poz]!=0) 
			i--;
		else 
		{					
			if(RS==1)
			{
				ll=(randl((long)(((double)MaxL/2.0)-10)))+((double)MaxL/2.0);
/*ll=50;
printf("Random length= %ld\n",ll);*/
				for(j=0;j<ll;j++)
				{
					jj=randl(4);
/*printf("jj= %d\n",jj);*/
					if(jj==0) grid[poz][j]='A';
					if(jj==1) grid[poz][j]='U';
					if(jj==2) grid[poz][j]='G';
					if(jj==3) grid[poz][j]='C';
				}
				grid[poz][ll]='\0';
				Hossz[poz]=strlen(grid[poz]);
			}
			else
			{
				
				jj=randl(3);
				strcpy(grid[poz],proba[jj]);
				Hossz[poz]=strlen(grid[poz]);
/*printf("jj= %d\n",jj);*/
			}
		
/*printf("%d) %s::%d (%d)\n",poz,grid[poz],Hossz[poz],strlen(grid[poz]));*/ 

			ff=foldol(activity[poz],grid[poz],Hossz[poz],BA);
/*for(j=0;j<POR;j++)
	printf("activity[%d][%d]= %f\t",poz,j,activity[poz][j]);
printf("\n");*/
	
			if(ff!=0)
			{
				for(jj=0;jj<POR;jj++)
					activity[poz][jj]=0.00;
			}
			
			
/*for(j=0;j<POR;j++)
	printf("activity[%d][%d]= %f\t",poz,j,activity[poz][j]);
printf("\n");*/
		
		}
  }
  for(i=0;i<size;i++)
	{
		if(Hossz[i]==0)
		{
			grid[i][0]='\0';
			for(jj=0;jj<POR;jj++)
					activity[i][jj]=0.00;
		}
	}
}
