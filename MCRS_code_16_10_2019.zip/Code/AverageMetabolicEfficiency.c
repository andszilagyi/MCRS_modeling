#include  "MRM_RNA_complementer.h"


/**
 Average Metabolic Efficiency in equilibrium: calculate each focal cell's metabolic efficience where exists empty site in replication neighbourhood within the metabolic neighbourhood of focal cell. Each value is make an average and it depends on diffusion 
 
 egyensulyban racs atlagot számolni minden metabolikus hatékonyságra: minden fokális egyedre kiszamolni a metabolikus hatékonyságot olyan esetekben ahol legalább egy ures hely van a Moore (metabolikus)szomszedsagon beluli Neumann (replikacios) szomszedsagban. Ennek a szamolt erteknek kell D-t fuggesset nezni
**/

void AverageMetabolicEfficiency(int time,int m, char **grid, int *MetNeigh,int MetNeighSize, double **Activity,double ex, int NumOfProperties, double c, double SubAddEff, int *LengthOfReplicators, int *RepNeigh,int RepNeighSize)
{
	int i, j, jj, num, NumOfRep;
	double AME, SD;
	
	double *index=NULL;
	
	/*printf("AverageMetabolicEfficiency\n");*/
	
	index=(double*)calloc(m,sizeof(double));
	if(index==NULL) exit(1);
	for(i=0;i<m;i++)
		index[i]=-100;
	
	
	AME=0.0;
	NumOfRep=0;
	for(i=0;i<m;i++)
	{
		/*printf("%d\n",i);*/
		if(LengthOfReplicators[i]>0)
		{
			num=0;			
			for(j=0;j<RepNeighSize;j++)
			{
				jj=RepNeigh[(i*RepNeighSize)+j];
				if(LengthOfReplicators[jj]==0)
				{
					num+=1;
					break;
				}
			}
			
			if(num>0)
			{
				NumOfRep+=1;
				/*printf("i= %d kozeleben van ureshely (NumOfRep= %d)\n",i, NumOfRep);*/				index[i]=metabolism(i,&MetNeigh[0],MetNeighSize,&Activity[0],ex,NumOfProperties,c, SubAddEff, &LengthOfReplicators[0]);
				AME+=index[i];
				/*printf("i= %d kozeleben van ureshely (NumOfRep= %d, AME= %f)\n",i, NumOfRep, AME);*/
			}
			else;
		}
		else;		
	}
	/*printf("\n");*/
	
	
	if(NumOfRep>0)
	{
		/*for(i=0;i<m;i++)
			printf("(%d)%f ",i,index[i]);
		printf("\n");*/
	
		SD=0.0;
		for(i=0;i<m;i++)
		{
			if(index[i]!=-100)
				SD+=pow(index[i]-AME/(double)NumOfRep,2);
			else;
		}
		if(NumOfRep>=2)
			SD=pow(SD/(NumOfRep-1),0.5);
		else SD=pow(SD/(NumOfRep),0.5);
	
		/*printf("%d %f+-%f\n",time, AME/(double)NumOfRep, SD);*/
		fprintf(AverageMetabolicEfficiencyFile,"%d %f %f %d\n",time, AME/(double)NumOfRep,SD,NumOfRep);
		fflush(AverageMetabolicEfficiencyFile);
	}
	else
	{
		/*printf("%d %f+-%f\n",time, 0.00, 0.00);*/
		fprintf(AverageMetabolicEfficiencyFile,"%d %f %f %d\n",time,0.00,0.00,NumOfRep);
		fflush(AverageMetabolicEfficiencyFile);
	
	}
	free(index);

}

