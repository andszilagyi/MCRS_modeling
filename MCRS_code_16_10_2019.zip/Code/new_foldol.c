#include  "MRM_RNA_complementer.h"

int foldol(double *akt, char *szov, int KK, double BasicAct)
{
/**	
*akt = the minimal energy of the folded sequence ([0]) + the values of enzymatic activities 1, 2 and three ([1], [2] and [3])
*szov = the sequence
KK = the length of the sequence
BasicActivity =
**/
	int Enz1Length=5;
	char *str,seq1[KK],*struct1;
	char string[3][20], ENZYME1[5+1]="GCGAU";/** !!! Change string[1] !!! **/
	int pos,nlen,i,j,loop[3][10]={{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1}}; /*mekkora loopok hol kezdodnek*/	
	float e1;
	temperature = 37.0f;
	float att[4]; /* optimalis hurokhossztol valo tavolsag hatasa*/
	/*float* akt;*/ /* free energy [0], activities [1,2,3] 
	akt=malloc(sizeof(float)*4);*/
	int numact=0, num=0, PatternStart=0, num2=0;

/*printf("************* FOLDOL *************\n");*/

	att[0]=0.1; /** _ _ C _ _ _  OR _ _ _ C _ _, where C is a compulsory base**/
	att[1]=0.8; /** _ _ C C _ _, where Cs are compulsory bases**/
	att[2]=0.9; /** _ A C C _ _  OR _ _ C C A _, where Cs are compulsory and A is an additional bases, which are pirimidines or purines **/
	att[3]=1.0; /** _ A C C A _  , where Cs are compulsory and A is an additional bases , which are pirimidines or purines**/


/*printf("BasicActivity= %f\n",BasicAct);*/

	strcpy(string[0],".....");
	strcpy(string[1],"(........)");
	strcpy(string[2],"(..............)");
/*strcpy(string[1],"(........)");*/


	strcpy(seq1, szov);
	struct1 = (char* ) space(sizeof(char)*(strlen(seq1)+1));
	e1=fold(seq1, struct1);
	free_arrays();
	/*printf("ENERGY= %f\n",e1);
	printf("seq1 =    %s\n",seq1);
	printf("struct1 = %s\n",struct1);
	printf("seq1[0]= %c, struct1[0]= %c\n",seq1[0],struct1[0]);*/
	/*for(i=0;i<strlen(seq1);i++)
		printf("%3d",i);
	printf("\n");
	for(i=0;i<strlen(seq1);i++)
		printf("%3c",seq1[i]);
	printf("\n");
	for(i=0;i<strlen(seq1);i++)
		printf("%3c",struct1[i]);
	printf("\n");*/
		
	
/** **//*exit(1);*/
	
	if(e1==0.00)
	{
		/*printf("kiugrok!\n");*/
		
		free(struct1);
		/*free(string);*/
		return 1;
	}	
	else
	{ /*e1 != 0*/

		
		for(i=0;i<3;i++)
		{
			for(j=0;j<10;j++)
				loop[i][j]=-1;
		} 
     
/*hurokkereses*/
		for(i=0;i<=2;i++)
		{
			pos=0;
			nlen=strlen(string[i]);
			str=struct1;
			/*printf("%d) nlen: %d, str= %s, struct1= %s\n",i, nlen,str,struct1);*/
/** **//*exit(1);*/		
 
			while (str !=NULL)
			{
				str=strstr(str,string[i]);
				/*printf("str: %s\n",str);*/

				if(str != NULL)
				{
					loop[i][pos]=KK-(int)strlen(str);
					/*printf("%d) keresett szerkezet: %d(%d, %s, %d-%d=%d)\n",i,loop[i][pos],pos, str, KK,(int)strlen(str),KK-(int)strlen(str));*/
					/*printf("%c:%c ;; %c:%c\n",seq1[0],struct1[0],seq1[1],struct1[1]);*/
					str += nlen;
					pos++;
					
				}
			}
		}
/** **//*exit(1);	*/
		/*for(i=0;i<=2;i++)
		{
			for(j=0;j<10;j++)
				printf("loop[%d][%d]= %d\n",i,j,loop[i][j]);
		}*/
/** **//*exit(111);	*/

/*printf("%f %f %f %f\n",akt[0],akt[1],akt[2],akt[3]);*/
		
/*printf("XX\n");*/
		
		
/** *******************************************************************************		
THE SMALLEST RIBOZYME
******************************************************************************* **/
		akt[1]=0.0;
		numact=0;

/** **/ i=0;

		while(loop[0][i]>=0)/*5 hosszu szekvencia */
		{
			/*printf("loop[%d][%d]= %d\n",0,i,loop[0][i]);*/
			num=0;
			if(loop[0][i]<(int)KK/2.0) /*balra keresi, hogy nem hurokban van-e a szekvencia*/
			{	
				for(j=0;j<loop[0][i];j++)
				{					
					if(struct1[j]=='(')
						num=num+1;
					else if (struct1[j]==')')
						num=num-1;
					else;
				}
			}
			else /*jobbra keresi, hogy nem hurokban van-e a szekvencia*/
			{
				for(j=loop[0][i];j<KK;j++)
				{
					if(struct1[j]=='(')
						num=num+1;
					else if (struct1[j]==')')
						num=num-1;
					else;
				}
			}
/** **//*printf("num= %d\n",num);*/
/** **//*exit(111);*/
			if(num==0)			
			{
				num2=0;
				PatternStart=loop[0][i];
				for(j=PatternStart;j<(PatternStart+Enz1Length);j++)
				{
					if(seq1[j]==ENZYME1[j-PatternStart])
						num2++;
				}
				if(num2==Enz1Length)
				{
					akt[1]+=1.0;
					numact++;
				}
			}
			else;
			i++;
	

		}
/*printf("akt[1]= %f, numact= %d\n",akt[1],numact);*/
if(numact>1)
	akt[1]/=numact;
else;
/*printf("akt[1]= %f\n",akt[1]);*/
/** **//*exit(111);*/

/** *******************************************************************************		
THE MIDLE LENGHT RIBOZYME:
******************************************************************************* **/
		akt[2]=0.0;
		numact=0;

		i=0;
		while(loop[1][i]>=0)
		{
			/*printf("loop[%d][%d]= %d\n",0,i,loop[1][i]);*/
			if((szov[loop[1][i]+4]=='G')&&(szov[loop[1][i]+5]=='G')) /* two compulsory bases */
			{
				if((szov[loop[1][i]+3]=='U')&&(szov[loop[1][i]+6]=='C')) /*two additional pyrimiden bases*/
				{
					akt[2]+=att[3];
					numact++;
				}
				else if((szov[loop[1][i]+3]=='U')||(szov[loop[1][i]+6]=='C')) /*one additional pyrimiden bases*/
				{
					akt[2]+=att[2];
					numact++;
				}
				else /*no additional pyrimiden bases*/
				{
					akt[2]+=att[1];
					numact++;
				}
			}
			else if((szov[loop[1][i]+4]=='G')||(szov[loop[1][i]+5]=='G')) /* one compulsory bases*/
			{
				akt[2]+=att[0];
				numact++;
			}
			else; /* no compulsory bases*/

			i++;
		}

/*printf("akt[2]= %f, numact= %d\n",akt[2],numact);*/
		if(numact>1)
			akt[2]/=numact;
		else;
/*printf("akt[2]= %f\n",akt[2]);*/
/** **//*exit(111);*/

/** *******************************************************************************		
 THE LARGEST RIBOZYME:
******************************************************************************* **/		
		akt[3]=0.0;	
		numact=0;

		i=0;
		while(loop[2][i]>=0)
		{
			if((szov[loop[2][i]+7]=='U')&&(szov[loop[2][i]+8]=='U')) /* two compulsory bases */
			{
				if((szov[loop[2][i]+6]=='A')&&(szov[loop[2][i]+9]=='C')) /*two additional purine bases*/
				{
					akt[3]+=att[3];
					numact++;
				}
				else if((szov[loop[2][i]+6]=='A')||(szov[loop[2][i]+9]=='C')) /*one additional purine bases*/
				{
					akt[3]+=att[2];
					numact++;
				}
				else /*no additional purine bases*/
				{
					akt[3]+=att[1];
					numact++;
				}
			}
			else if((szov[loop[2][i]+7]=='U')||(szov[loop[2][i]+8]=='U')) /* one compulsory bases*/
			{
				akt[3]+=att[0];
				numact++;
			}
			else; /* no compulsory bases*/

			i++;
		}

/*printf("akt[3]= %f, numact= %d\n",akt[3],numact);*/
		if(numact>1)
			akt[3]/=numact;
		else;
/*printf("akt[3]= %f\n",akt[3]);*/
/** **//*exit(111);*/

		akt[0]=(-1.0*e1);
		if(akt[0]>25.0)
			akt[0]=25.0;

		/*printf("vege\n");*/
		free(struct1);
		/*free(string);*/
		return 0;
	}/*e1 != 0*/
}
