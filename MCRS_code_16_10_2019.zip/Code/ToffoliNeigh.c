#include  "MRM_RNA_complementer.h"

/******************************************************************************
It gives the focal cell and its neighbourhoods for ToffoliMargolus algorithm
*******************************************************************************/
void ToffoliNeigh(int mm,int *neighbourhood)
{/* neighbourhood for Toffoli's algorithm */
 /*****************************************************************************
mm=             size of matrix
neighbourhood=  it is a matrix to where is collected the focal cell and
                its neighbours
*******************************************************************************/

 int z,k,i,j,ii,jj;

  k=-1;
  for(z=0;z<(mm*mm);z++)
  {/*for*/
    k++;
    *(neighbourhood+k)=z; /*left upper*/
    i=(int)(z/mm);/*row*/
    j=z%mm;/*column*/

    k++;
    jj=torus(j+1,mm);
    *(neighbourhood+k)=(i*mm)+jj; /*right upper*/

    k++;
    ii=torus(i+1,mm);
    *(neighbourhood+k)=(ii*mm)+j; /*left under*/

    k++;
    ii=torus(i+1,mm);
    jj=torus(j+1,mm);
    *(neighbourhood+k)=(ii*mm)+jj; /*east*/

  }/*for*/

  /*printf("neighbourhood for Toffoli's algorithm\n\n");
  for(i=0;i<mm*mm;i++)
  {
    printf("i= %d\t",i);
    for(j=0;j<4;j++)
    printf("%d\t",*(neighbourhood+(i*4)+j));
    printf("\n");
  }
  printf("\n");*/
}/* neighbourhood for Toffoli's algorithm */

