#include  "MRM_RNA_complementer.h"

/******************************************************************************
                It gives the focal cell and its Moore-neighbours!!!!
*******************************************************************************/
void moore(int mm,int *neighbourhood,int neigh_s,int nh)
{/*moore*/
/*****************************************************************************
mm=             size of matrix
neighbourhood=  it is a matrix to where is collected the focal cell and
                its neighbours
neigh_s_size of neighbourhood
nh= number of neighbours
*******************************************************************************/

int z,k,i,j,ii,jj,g;

/*printf("nh= %d\n",nh);*/


  /*printf("mm= %d, neigh_s= %d, nh= %d\n",mm,neigh_s,nh);*/
  for(i=0;i<mm;i++)
  {
    for(j=0;j<mm;j++)
    {
      z=0;
      for(ii=i-neigh_s;ii<=i+neigh_s;ii++)
      {
        k=torus(ii,mm);
        for(jj=j-neigh_s;jj<=j+neigh_s;jj++)
        {
          g=torus(jj,mm);
          z++;
          if((k==i)&&(g==j))
          {
           *(neighbourhood+(i*mm*nh)+(j*nh)+0)=(k*mm)+g;
            z--;
          }
          else *(neighbourhood+(i*mm*nh)+(j*nh)+z)=(k*mm)+g;

        }
      }
    }
  }


  /*printf("Moore neighbourhood\n\n");
  for(i=0;i<mm;i++)
  {
    for(j=0;j<mm;j++)
    {
      printf("i= %2d ",(i*mm)+j);
      for(z=0;z<nh;z++)
        printf("%2d ",*(neighbourhood+(i*mm*nh)+(j*nh)+z));
      printf("\n");
    }

  }
  printf("\n");*/

}/*moore*/
