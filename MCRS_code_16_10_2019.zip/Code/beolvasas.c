#include  "MRM_RNA_complementer.h"

void beolvasas(char **SeqMatrix, double **EnzymeActMatrix, int *LengthMatrix, int GridSize, char *FileName, int InitialRep,int FeaturesOfRep,int LOfRep,int FileExistence)
{
	int i, OS=1,similarity=0,/* *index=NULL,*/poz,*L=NULL;
	long long int /*row,*/wcl;
	long int rn;
	/*long long int *ROW=NULL;*/
	char *s=NULL,*sn=NULL,**seq;
	double **EA;
	
	/*printf("BEOLVASAS\n");*/
	
	OS=OS;
	
	similarity=strcmp(FileName,"input_final_matrix.dat");
	/*printf("similarity= %d\n",similarity);*/

	if(similarity!=0)
	{
		/*printf("Sequence from a Pool\n");*/
		
		if(FileExistence==0)
		{
			/*printf("RandSeqMatrix.dat exists!\n");*/
			input=fopen("RandSeqMatrix.dat","r");
			i=0;
			while(i<(GridSize*GridSize))
			{
				OS=fscanf(input,"%s %d %lf %lf %lf %lf\n",&SeqMatrix[i][0],&LengthMatrix[i],&EnzymeActMatrix[i][0],&EnzymeActMatrix[i][1],&EnzymeActMatrix[i][2],&EnzymeActMatrix[i][3]);
				if(LengthMatrix[i]==0)
					SeqMatrix[i][0]='\0';
			
				i++;
			}
			fclose(input);
		}
		else
		{	
			/*printf("RandSeqMatrix.dat does not exist!\n");*/
				
			do
			{
				rn=randl(WCL);
				/*printf("rn= %ld\n",rn);*/
			}
			while((rn-1)+InitialRep>(WCL-1));
			
			s=(char*)calloc(1000,sizeof(char));
			sn=(char*)calloc(1000,sizeof(char));
			strcpy(s,"head -n ");
			OS=sprintf(sn,"%ld",(rn-1)+InitialRep);
			strcat(s,sn);
			free(sn);
			sn=(char*)calloc(1000,sizeof(char));
			strcat(s," temp | tail -n ");
			OS=sprintf(sn,"%d",InitialRep);
			strcat(s,sn);
			strcat(s," > RandSeqMatrix.dat");
			/*printf("s= %s\n",s);*/
			/*strcat(s," temp > temp2");
			printf("s= %s\n",s);*/
			OS=system(s);
			free(s);
			free(sn);

			/*s=(char*)calloc(1000,sizeof(char));
			sn=(char*)calloc(1000,sizeof(char));
			strcpy(s," | tail -n ");
			OS=sprintf(sn,"%d",InitialRep);
			strcat(s,sn);
			strcat(s," temp2 > RandSeqMatrix.dat");
			printf("s= %s\n",s);
			OS=system(s);
			OS=system("rm -f temp2");
			free(s);
			free(sn);*/

		
			input=fopen("RandSeqMatrix.dat","r"); 
		
			if(InitialRep==(GridSize*GridSize))
			{
				i=0;
				while(i<InitialRep)
				{
					OS=fscanf(input,"%s %d %lf %lf %lf %lf\n",&SeqMatrix[i][0],&LengthMatrix[i],&EnzymeActMatrix[i][0],&EnzymeActMatrix[i][1],&EnzymeActMatrix[i][2],&EnzymeActMatrix[i][3]);
					i++;
				}
			}
			else
			{
				L=(int*)calloc(InitialRep,sizeof(int));
				seq=(char**)calloc(InitialRep,sizeof(char*));
				for(i=0;i<InitialRep;i++)
					seq[i]=(char*)calloc(LOfRep+1,sizeof(char));
				for(i=0;i<InitialRep;i++)
					seq[i][0]='\0';
				EA=(double**)calloc(InitialRep,sizeof(double*));
				for(i=0;i<InitialRep;i++)
					EA[i]=(double*)calloc(FeaturesOfRep,sizeof(double));
		
				i=0;
				while(i<InitialRep)
				{
					OS=fscanf(input,"%s %d %lf %lf %lf %lf\n",&seq[i][0],&L[i],&EA[i][0],&EA[i][1],&EA[i][2],&EA[i][3]);
					i++;
				}
			
				i=0;
				for(i=0;i<InitialRep;i++)
				{
					poz=randl(GridSize*GridSize);
					/*printf("LengthMatrix[%d]= %d\n",poz,LengthMatrix[poz]);*/
					if(LengthMatrix[poz]!=0)
						i--;
					else
					{	
						strcpy(&SeqMatrix[poz][0],&seq[i][0]);
						EnzymeActMatrix[poz][0]=EA[i][0];
						EnzymeActMatrix[poz][1]=EA[i][1];	
						EnzymeActMatrix[poz][2]=EA[i][2];
						EnzymeActMatrix[poz][3]=EA[i][3];
						LengthMatrix[poz]=L[i];				
					}				
			
				}
				for(i=0;i<GridSize*GridSize;i++)
				{
					if(LengthMatrix[i]==0)
						SeqMatrix[i][0]='\0';
				}
				
				
				free(L);
				for(i=0;i<InitialRep;i++)
				{
					free(seq[i]);
					free(EA[i]);
				}
				free(seq);
				free(EA);
			}
			fclose(input);
			
		}
		
		
	}
	else
	{
		/*printf("Sequence from an earlier running\n");*/
		
		OS=system ("cat input_final_matrix.dat | wc -l > hossz.dat");
		input=fopen("hossz.dat","r");
		OS=fscanf(input,"%lld\n",&wcl);
		fclose(input);
		OS=system("rm -f hossz.dat");
		printf("the result of command: wc -l final_matrix_proba.dat is %lld\n",wcl);
	
		input=fopen("input_final_matrix.dat","r"); 
	
		i=0;
		while(i<wcl)
		{
			OS=fscanf(input,"%s %d %lf %lf %lf %lf\n",&SeqMatrix[i][0],&LengthMatrix[i],&EnzymeActMatrix[i][0],&EnzymeActMatrix[i][1],&EnzymeActMatrix[i][2],&EnzymeActMatrix[i][3]);
			if(LengthMatrix[i]==0)
				SeqMatrix[i][0]='\0';
			
			i++;
		}
	}
	
}


/*OS=system("rm -f temp");*/
		
		/*s=(char*)calloc(1000,sizeof(char));
		strcpy(s,"cat ");
		strcat(s,FileName);
		strcat(s," | wc -l > hossz.dat");
		printf("s= %s\n",s);
		input=fopen("hossz.dat","r");
		OS=fscanf(input,"%lld\n",&wcl);
		fclose(input);
		OS=system("rm -f hossz.dat");

		OS=system(s);
		OS=system("cat hossz.dat");

		
		L=(int*)calloc(wcl,sizeof(int));
		seq=(char**)calloc(wcl,sizeof(char*));
		for(i=0;i<wcl;i++)
		{
			if(fmod(i,1E4)==0)
				printf("1E4\n");
			seq[i]=(char*)calloc(LOfRep+1,sizeof(char));
		}
		EA=(double**)calloc(wcl,sizeof(double*));
		for(i=0;i<wcl;i++)
			EA[i]=(double*)calloc(FeaturesOfRep,sizeof(double));
		fp=fopen(FileName,"r");
		i=0;
		while(i<wcl)
		{
			OS=fscanf(fp,"%s %d %lf %lf %lf %lf",&seq[i][0],&L[i],&EA[i][0],&EA[i][1],&EA[i][2],&EA[i][3]);
			i++;
		}
		
		i=0;
		for(i=0;i<InitialRep;i++)
		{
			poz=randl(GridSize);
			if(LengthMatrix[poz]!=0)
				i--;
			else
			{
				row=randl(wcl);
				strcpy(&SeqMatrix[poz][0],&seq[row][0]);
				EnzymeActMatrix[poz][0]=EA[row][0];
				EnzymeActMatrix[poz][1]=EA[row][1];
				EnzymeActMatrix[poz][2]=EA[row][2];
				EnzymeActMatrix[poz][3]=EA[row][3];
				LengthMatrix[poz]=L[row];				
			}
			
		}*/
		

/*fp=fopen("RowsFromSeqList.dat","w");
		fclose(fp);
		
		fp=fopen("RowsFromSeqList.dat","a");
		for(i=0;i<InitialRep;i++)
		{
			fprintf(fp,"%ld\n",randl(12608893));
			fflush(fp);
		}
		fclose(fp);
		
		
		OS=system("cat RowsFromSeqList.dat | sort -n > SortedRowsFromSeqList.dat");*/
		/*ROW(long long int*)calloc(InitialRep,sizeof(long long int));*/
		
		
		/*strcpy(s,"awk '");
		fp=fopen("SortedRowsFromSeqList.dat","r");
		for(i=0;i<InitialRep;i++)
		{
			OS=fscanf(fp,"%lld\n",&row);
			OS=sprintf(sn,"%lld",row);
			printf("%lld %s\n",row,sn);
			strcat(s,"NR==");
			strcat(s,sn);
			if(i<(InitialRep-1))
				strcat(s,";");
			else 
			{
				strcat(s," {print;exit}' ");
				strcat(s,FileName);
				strcat(s," >> RandSeqMatrix.dat");
				printf("s= %s\n",s);
			}
		}
		fclose(fp);
		OS=system(s);
		
		
		exit(4558);
		ree(s);
		free(sn);*/
		
		

