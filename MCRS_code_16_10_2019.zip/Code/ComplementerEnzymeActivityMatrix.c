#include  "MRM_RNA_complementer.h"

void ComplementerEnzymeActivityMatrix(int LocalTime, int m, int NoE, int l, int BA, char **grid, double **activity, int *length)
{
/*
 LocalTime	time (t)
 mm 				size of grid (m)
 NoE				Number of enzyme type (NoE)
 l					maximal length of sequences (L)
 BA					basic enzyme activity (BA)
 **grid 		matrix of sequence (**matrix)
 **activity matrix of enzyme activity and Energy (**enzyme)
 *length		matrix of the length of seqvences (*Length) 
 
 */
	
	char *ss=NULL, *ssn=NULL, **CompMatrix, *Cs=NULL, *Csn=NULL, *tt=NULL;
	double **CompEnzyme;
	int *CompLength=NULL; 
	int **res, mm;
	
	int PropOfRep=0, L1=0,ff=0,replicators=0;
	int i,j,jj,ii;
	/*double dd;*/
	char *EnzymePattern[8]={"E100","E020","E003","E120","E103","E023","E123","E000"};
	char *FileName=NULL;
	

	
	/*printf("KIERTKElO\n");*/
	PropOfRep=NoE+1;
	L1=l+1;
	mm=m*m;
	
	CompMatrix=(char**) calloc(mm,sizeof(char*));
	if(CompMatrix==NULL) exit(1);
	for(i=0;i<mm;i++)
		CompMatrix[i]=(char*) calloc(L1,sizeof(char));
	
	for(i=0;i<mm;i++)
		CompMatrix[i][0]='\0';
		
	CompEnzyme=(double**) calloc(mm,sizeof(double*));
	if(CompEnzyme==NULL) exit(1);
	for(i=0;i<mm;i++)
		CompEnzyme[i]=(double*) calloc(PropOfRep,sizeof(double));
	
	CompLength=(int*) calloc(mm,sizeof(int));
	if(CompLength==NULL) exit(1);
	ss=(char*) calloc(10,sizeof(char));
	if(ss==NULL) exit(1);
	ssn=(char*) calloc(10,sizeof(char));
  if (ssn==NULL) exit (1);
	Cs=(char*) calloc(10,sizeof(char));
	if(Cs==NULL) exit(1);
	Csn=(char*) calloc(10,sizeof(char));
  if (Csn==NULL) exit (1);
	
	
	res=(int**) calloc(8,sizeof(int*));
	if(res==NULL) exit(1);
	for(i=0;i<8;i++)
		res[i]=(int*) calloc(8,sizeof(int));
	
	/*test_printing(m,L1,PropOfRep,&grid[0],&length[0], &activity[0]);*/
	replicators=0;
	for(i=0;i<mm;i++)
	{
		/*printf("%d: %s %d\n",i,grid[i], length[i]);*/
		if(length[i]>0)
		{
			replicators+=1;
			KiertekeloComplementer(i, i, &grid[0], length[i], &CompMatrix[0]);
			CompLength[i]=length[i];
			ff=foldol(CompEnzyme[i],CompMatrix[i],CompLength[i],BA);
			if(ff!=0)
			{
				for(jj=0;jj<PropOfRep;jj++)
				CompEnzyme[i][jj]=0.00;
			}
		}
	}
	
/*test_printing(m,L1,PropOfRep,&CompMatrix[0],&CompLength[0], &CompEnzyme[0]);*/

	for(i=0;i<mm;i++)
	{
		/*SORTING OF ORIGINAL SEQUENCE*/
		if(length[i]>0)
		{
			strcpy(ss,"E");
			for(j=1;j<=NoE;j++)
			{
				if(activity[i][j]>0.01) /*Real enzyme*/
				{
					sprintf(ssn,"%d",j);
					strcat(ss,ssn);
				}
				else strcat(ss,"0");
			}
			
		}
		else continue;
		
		/*SORTING OF ORIGINAL SEQUENCE*/
		if(CompLength[i]>0)
		{
			strcpy(Cs,"E");
			for(j=1;j<=NoE;j++)
			{
				if(CompEnzyme[i][j]>0.01) /*Real enzyme*/
				{
					sprintf(Csn,"%d",j);
					strcat(Cs,Csn);
				}
				else strcat(Cs,"0");
			}
			
		}
		else continue;
		
		/*printf("%d: %s(%d) <--> %s(%d)\n",i,ss,length[i],Cs,CompLength[i]);*/
		
		for(ii=0;ii<8;ii++)
		{
			if(strcmp(ss,EnzymePattern[ii])==0)
			{
				/*printf("%s == %s\n",s,EnzymePattern[ii]);*/
				for(jj=0;jj<8;jj++)
				{
					if(strcmp(Cs,EnzymePattern[jj])==0)
					{
						/*printf("%s == %s <--> %s == %s\n",s,EnzymePattern[ii],EnzymePattern[jj],Cs);*/
						res[ii][jj]+=1;
						break;
					}
					
				}
			}
			else;
		}	
		
		
	}
/*printf("kiiratas\n");*/
	FileName=(char*) calloc(1000,sizeof(char));
  if(FileName==NULL) exit(1);
	
	tt=(char*) calloc(1000,sizeof(char));
  if(tt==NULL) exit(1);

	/*printf("_Complementer_enzyme_activity_matrix.dat\n");*/
	strcpy(FileName,"_Complementer_enzyme_activity_matrix.dat");

/*printf("time= %d, tt= %s\n",LocalTime,tt);*/
	sprintf(tt,"%d",LocalTime);
/*printf("time= %d, tt= %s\n",LocalTime,tt); */
	strcat(tt,FileName);
	/*printf("%s\n",tt);*/
	compoutput=fopen(tt,"w");
	for(ii=0;ii<8;ii++)
	{
		for(jj=0;jj<8;jj++)
		{
			/*printf("%d ",res[ii][jj]);*/
			fprintf(compoutput,"%f ",(double)res[ii][jj]/(double)replicators);
		}
		/*printf("\n");*/
		fprintf(compoutput,"\n");
	}
	/*printf("\n");*/
	fprintf(compoutput,"\n");
	fflush(compoutput);
	fclose(compoutput);
	
	
	/*dd=0.0;
	for(ii=0;ii<8;ii++)
	{
		for(jj=0;jj<8;jj++)
			dd+=(double)res[ii][jj]/(double)replicators;
	}
	printf("dd= %f\n",dd);
	exit(1);*/
	
	
	/*printf("%s %f %f %f %f %d\n",grid[0],activity[0][0], activity[0][1],activity[0][2],activity[0][3],length[0]);
	printf("%s %f %f %f %f %d\n\n",CompMatrix[0],CompEnzyme[0][0], CompEnzyme[0][1],CompEnzyme[0][2],CompEnzyme[0][3],CompLength[0]);
	ff=foldol(activity[0],grid[0],length[0],BA);	ff=foldol(CompEnzyme[0],CompMatrix[0],CompLength[0],BA);
	printf("%s %f %f %f %f %d\n",grid[0],activity[0][0], activity[0][1],activity[0][2],activity[0][3],length[0]);
	printf("%s %f %f %f %f %d\n\n",CompMatrix[0],CompEnzyme[0][0], CompEnzyme[0][1],CompEnzyme[0][2],CompEnzyme[0][3],CompLength[0]);*/
	
	for(i=0;i<mm;i++)
	{
		free(CompMatrix[i]);
		free(CompEnzyme[i]);
	}
	free(CompMatrix);
	free(CompEnzyme);
	for(i=0;i<8;i++)
		free(res[i]);
	free(res);
	free(CompLength);
	free(ss);
	free(ssn);
	free(Cs);
	free(Csn);
	free(FileName);
	free(tt);
/*printf("XX\n\n");*/
	
}


