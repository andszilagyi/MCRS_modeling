#include  "MRM_RNA_complementer.h"

double b_valtozas(double bmax,double bmin,int time,int step)
{
	return bmin+(((bmax-bmin)/step)*time);
}
