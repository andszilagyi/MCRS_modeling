#include  "MRM_RNA_complementer.h"

/******************************************************************************
                It gives the focal cell and its von Neumann-neighbours!!!!
*******************************************************************************/
void neumann(int mm,int *neighbourhood)
{/*neumann*/
 /*****************************************************************************
mm=             size of matrix
neighbourhood=  it is a matrix to where is collected the focal cell and
                its neighbours
*******************************************************************************/

 int z,k,i,j,ii,jj;

  k=-1;
  for(z=0;z<(mm*mm);z++)
  {/*for*/
    k++;
    *(neighbourhood+k)=z;
    i=(int)(z/mm);/*row*/
    j=z%mm;/*column*/

    k++;
    ii=torus(i-1,mm);
    *(neighbourhood+k)=(ii*mm)+j; /*north*/

    k++;
    jj=torus(j+1,mm);
    *(neighbourhood+k)=(i*mm)+jj; /*east*/

    k++;
    ii=torus(i+1,mm);
    *(neighbourhood+k)=(ii*mm)+j; /*south*/

    k++;
    jj=torus(j-1,mm);
    *(neighbourhood+k)=(i*mm)+jj; /*west*/
  }/*for*/

  /*printf("von Neumann neighbourhood\n\n");
  for(i=0;i<mm*mm;i++)
  {
    printf("i= %d\t",i);
    for(j=0;j<5;j++)
    printf("%d\t",*(neighbourhood+(i*5)+j));
    printf("\n");
  }
  printf("\n");*/
}/*neumann*/

