#include  "MRM_RNA_complementer.h"

int factorial(int n)
{
	int res=1;
	while(n>1)
	{
		res*=n;
		n--;
	}
	return res;
}
