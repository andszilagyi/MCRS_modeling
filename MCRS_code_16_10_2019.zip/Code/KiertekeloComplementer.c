#include  "MRM_RNA_complementer.h"

void KiertekeloComplementer(int ii, int poz, char **grid, int LL, char **CompGrid)
{
	/*char BASES[5]="AUGC", CBASES[5]="UACG";*/
	int i/*,j*/;
	
	/*printf("COMPLEMENTER\n");
		
/** **/	/*printf("%s\n",grid[ii]);*/
	for(i=0;i<LL;i++)
	{
		switch(grid[ii][i])
		{
			case 'A':
				CompGrid[poz][(LL-1)-i]='U';
				break;
			case 'U':
				CompGrid[poz][(LL-1)-i]='A';
				break;
			case 'G':
				CompGrid[poz][(LL-1)-i]='C';
				break;
			case 'C':
				CompGrid[poz][(LL-1)-i]='G';
				break;
			default:
				printf("No complementer\n");
		}
	}
/** **/	/*printf("%s\n%s\n",grid[ii],CompGrid[poz]);*/
/** **/ /*exit(1111);	*/

}



void KiertekeloComplementerOLD(int ii, int poz, char **grid, int LL, char **CompGrid)
{
	/*char BASES[5]="AUGC", CBASES[5]="UACG";*/
	int i/*,j*/;
	
	/*printf("COMPLEMENTER\n");
		
	printf("%s\n",grid[ii]);*/
	for(i=0;i<LL;i++)
	{
		switch(grid[ii][i])
		{
			case 'A':
				CompGrid[poz][i]='U';
				break;
			case 'U':
				CompGrid[poz][i]='A';
				break;
			case 'G':
				CompGrid[poz][i]='C';
				break;
			case 'C':
				CompGrid[poz][i]='G';
				break;
			default:
				printf("No complementer\n");
		}
	}
	/*printf("%s\n%s\n",grid[ii],CompGrid[poz]);*/
	

}



