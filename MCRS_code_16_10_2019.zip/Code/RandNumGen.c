#include  "MRM_RNA_complementer.h"

/*#define AA 471
#define B 1586
#define CC 6988
#define DD 9689
#define MM 16383
#define RIMAX 2147483648.0 */       /* = 2^31 */
/*#define RandomInteger (++nd, ra[nd & MM] = ra[(nd-AA) & MM] ^ra[(nd-B) & MM] ^ ra[(nd-CC) & MM] ^ ra[(nd-DD) & MM])
static long ra[MM+1], nd;*/

void seed(long seed)
{
	int  i;
	
	if(seed<0) { puts("SEED error."); exit(1); }
	ra[0]= (long) fmod(16807.0*(double)seed, 2147483647.0);
	/*printf("ra[%d]= %ld\n",0,ra[0]);*/
	for(i=1; i<=MM; i++)
	{
		ra[i] = (long)fmod( 16807.0 * (double) ra[i-1], 2147483647.0);
		/*printf("ra[%d]= %ld\n",i,ra[i]);*/
	}
}

double randd(void)
{
  return((double) RandomInteger / RIMAX);
}

long randl(long num)      /* random number between 0 and num-1 */
{
  return (RandomInteger % num);
}

