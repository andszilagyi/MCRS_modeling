#include  "MRM_RNA_complementer.h"

/*******************************************************************************
          IT GIVES THE TORUS OC CELLAULAR AUTOMATON
********************************************************************************/

int torus(int k, int m)
{/*torus*/
/*****************************************************************
k: it is a grid point for what it is determined the torus
m: size of matrix
*****************************************************************/
  return ((m-((m-k)%m)))%m;
}/*torus*/