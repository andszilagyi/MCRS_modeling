#include  "MRM_RNA_complementer.h"

void complementer (int ii, int poz, char **grid, int LL)
{
	/*char BASES[5]="AUGC", CBASES[5]="UACG";*/
	int i/*,j*/;
		
/** **/	/*printf("%s\n",grid[ii]);*/
	for(i=0;i<LL;i++)
	{
		switch(grid[ii][i])
		{
			case 'A':
				grid[poz][(LL-1)-i]='U';
				break;
			case 'U':
				grid[poz][(LL-1)-i]='A';
				break;
			case 'G':
				grid[poz][(LL-1)-i]='C';
				break;
			case 'C':
				grid[poz][(LL-1)-i]='G';
				break;
			default:
				printf("No complementer\n");
		}
	}
/** **/	/*printf("%s\n%s\n",grid[ii],grid[poz]);*/
/** **/	/*exit(1111);*/
	

}


void complementerOLD(int ii, int poz, char **grid, int LL)
{
	/*char BASES[5]="AUGC", CBASES[5]="UACG";*/
	int i/*,j*/;
		
	/*printf("%s\n",grid[ii]);*/
	for(i=0;i<LL;i++)
	{
		switch(grid[ii][i])
		{
			case 'A':
				grid[poz][i]='U';
				break;
			case 'U':
				grid[poz][i]='A';
				break;
			case 'G':
				grid[poz][i]='C';
				break;
			case 'C':
				grid[poz][i]='G';
				break;
			default:
				printf("No complementer\n");
		}
	}
	/*printf("%s\n%s\n",grid[ii],grid[poz]);*/
	

}
