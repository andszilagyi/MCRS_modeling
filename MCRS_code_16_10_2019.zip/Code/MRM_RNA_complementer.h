#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <utils.h>
#include <fold_vars.h>
#include <fold.h>
#include <stdint.h>
#include <inttypes.h>

#define AA 471
#define B 1586
#define CC 6988
#define DD 9689
#define MM 16383
#define RIMAX 2147483648.0        /* = 2^31 */
#define RandomInteger (++nd, ra[nd & MM] = ra[(nd-AA) & MM] ^ra[(nd-B) & MM] ^ ra[(nd-CC) & MM] ^ ra[(nd-DD) & MM])
#define WCL 12608893 /*number of rows of ListOfSequencePart1.fmdat: wc -l ListOfSequencePart1.dat*/
long long int ra[MM+1], nd;

FILE *output,*input,*E1E2E3, *MatrixRajz, *hist,*mut, *EnergyE1,*EnergyE2,*EnergyE3,*EnergyE12,*EnergyE13,*EnergyE23,*EnergyE123,*EnergyFunctionless,*AverageMetabolicEfficiencyFile, *compoutput,*SeqList,*fp;

void diffusion(int ,int *,char ** ,double **,int, int *);
int foldol(double*, char *,int, double);
int torus(int,int);
void moore(int,int *,int,int);
void neumann(int,int *);
void ToffoliNeigh(int, int *);
double metabolism(int ,int *,int ,double **,double, int,double,double, int*);
double printing(int,int,double **,int,double *, int, char **, double,double,int *,double, double);
int factorial(int);
void MatrixDrawing(double **, int , int); 
void seed(long seed);
long randl(long num);
double randd(void);
void AverageMetabolicEfficiency(int,int,char **,int *,int,double **,double, int,double,double,int *,int *,int);
void complementer(int, int, char**, int);
void beolvasas(char**, double**, int*, int,char *,int,int,int,int);
void ComplementerEnzymeActivityMatrix(int,int,int,int,int,char **,double **,int *);
void KiertekeloComplementer(int, int, char**, int, char **);
void RandomPattern(char **,double **,int *,double,int,double,int,int,int);
double b_valtozas(double,double ,int ,int );


