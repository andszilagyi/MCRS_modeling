#include  "MRM_RNA_complementer.h"

/*****************************************************************
                      METABOLISM
*****************************************************************/
double metabolism(int pozition,int *Neigh,int MetNeighSize,double **Activity,double ex,  int NumOfProperties, double c, double SubAddEff, int *LengthOfReplicators)
{/*metabolism*/
/*********************************
pozition:							the grid poin whom the metabolic efficiency is calculated
*Neigh:								metabolic neighbourhoods
MetNeighSize     			number of metabolic neighbourhoods
ex :             			exponent in the calculationj of metabolic efficiency
*grid:          			CA matrix
NumOfProperties:			energy + enzyme activities (1+3)
c:										constant of Boltzmann distribution (P=1/(1+exp(-c*Energy)), where 
											p is [0.5,1] and Energy is stored in Activity[poz][0] 
											(Energy of RNA))	
SubAddEff: 						sub-additive effect on enzymatyc activities in promiscous enzyme
*LengthOfREplicators: lenght of replicators
*********************************/
/*metabolism(RepNeigh[(poz*NumOfRepNeigh)+i],&MetNeigh[0],NumOfMetNeigh,&enzyme[0],Exponent,&matrix[poz][0],NumOfEnzymes); */

/** 
1) MINDEN REPLIKÁTOR LEHET FELTEKEREDETT VAFGY LETEKEREDETT ÁLLAPOTBAN, ENNEK VALOSZINUSEGET BOLTZMANN ELOSZLASBOL LEHET KISZAMOLNI (P=1/(1+EXP(-c*E))) EZZEL KELL MINDEN ENZIMAKTIVITÁAST MEGSZOROZNI, HOGY MEGMONDJUK MEKKOR EGY ADOTT ENZIM KATALITIKUS HATEKONYSAGA (HA NAGYON INSTABIL AZ ENZIM, AKKOR KIS VALOSZINUSEGGEL VAN HELYES KONFORMACIOBAN IGY NEM IS NAGYON TUD ENZIMKENT MUKODNI)
2) KET VAGY HÁROM AKTIVITÁSSAL RENDELEKZŐ ENZIMNÉL CSÖKKENTENI KELL AZ EGYES ENZIM HATEKONYSAGOKAT, MERT IDO KELL A AZ EGYIK KONFORMÁCIÓBOL A MÁSIKBA VALÓ ÁTMENETHEZ. CSOKKENTESI TENYEZO: f.
**/


	int i,j,ii,num;
	double *act=NULL,f;
	double sum=1.0,boltzmann;
	
	/*printf("MEATBOLISM\npoz= %d\n", pozition);*/
	
	act=(double*) calloc(NumOfProperties,sizeof(double)); /*0: energy of replicator, 1 .. n: activities of enzymes function*/
  if(act==NULL) exit(1);
	
	/*for(i=0;i<NumOfProperties;i++)
    printf("%d: %f\n",i,act[i]);*/

	for(i=0;i<MetNeighSize;i++)
  {
		ii=Neigh[(pozition*MetNeighSize)+i];
		/*printf("%d. Neigh: %d: %f %f %f %f %d\n", i,ii,Activity[ii][0],Activity[ii][1],Activity[ii][2],Activity[ii][3],LengthOfReplicators[ii]);*/
		if(LengthOfReplicators[ii]>0)
		/*if(Activity[ii][0]>0)*/
		{
		
			num=0;
			for(j=1;j<NumOfProperties;j++)
			{
				if(Activity[ii][j]>0.0)
					num++;
			}
			if(num>0) /* f treats the primiscuity of enzymatic activities (see 2))  */
				f=1.0/(double)pow(num,SubAddEff);
			else f=0.0;
						
			boltzmann=1.0/(1.0+exp(-c*Activity[ii][0])); /* Lásd 1) */
			/*printf("f= %f, b: %f (%f)\n",f,boltzmann,-c);*/
			for(j=1;j<NumOfProperties;j++)
			{
				act[j]+=(f*boltzmann*Activity[ii][j]);
				/*printf("act[%d]=%f, %f\n",j,act[j],(f*boltzmann*Activity[ii][j]));*/
			}
				/*printf("\n");*/
		}
		else;
	}
  /*printf("\nSum of enzymatic activities in the metabolic neighbourhood:\n");*/
  /*for(i=0;i<NumOfProperties;i++)
    printf("%d: %f\n",i,act[i]);*/
	
	
	for(i=1;i<NumOfProperties;i++) 
    sum*=act[i];
	/*printf("Product of replicator types: %f (claim: %f)\n",sum,pow(sum,ex));*/
	
	free(act);
	if(sum==0)
		return 0.00;
	else
		return pow(sum,ex);
}/*metabolism*/
